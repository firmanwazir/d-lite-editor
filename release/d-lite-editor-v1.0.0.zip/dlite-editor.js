/*!
 * D-Lite Editor v1.0.0 (Production Release)
 * https://github.com/your-repo/d-lite-editor
 * (c) 2026 D-Lite Editor. Released under MIT License.
 * Modern, Lightweight & Extensible WYSIWYG Rich Text Editor Plugin
 */
(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
  typeof define === 'function' && define.amd ? define(factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, (function () {
    var exports = factory();
    global.DLiteEditor = exports.DLiteEditor;
    global.DLiteToast = exports.DLiteToast;
    global.DLiteModal = exports.DLiteModal;
    global.dliteToast = exports.toast;
    global.dliteModal = exports.modal;
    global.Sanitizer = exports.Sanitizer;
    global.Icons = exports.Icons;
  })());
})(this, function () {
  'use strict';

// --- Module: src/ui/Icons.js ---
/**
 * Modern stroke-based SVG icons for D-Lite Editor
 */
const Icons = {
  undo: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/></svg>`,
  redo: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 7v6h-6"/><path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3L21 13"/></svg>`,
  bold: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/><path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/></svg>`,
  italic: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="4" x2="10" y2="4"/><line x1="14" y1="20" x2="5" y2="20"/><line x1="15" y1="4" x2="9" y2="20"/></svg>`,
  underline: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3v7a6 6 0 0 0 12 0V3"/><line x1="4" y1="21" x2="20" y2="21"/></svg>`,
  strikethrough: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.3 4.9c-2.3-1.4-5.5-1.2-7.5.3-2.1 1.6-2.2 4.4-.3 6.1 1 1 2.5 1.7 4.2 2.3 2.5.9 4.3 2.1 4.3 4.1 0 2.2-2.1 3.8-4.8 3.8-2.6 0-5.1-1.3-6.2-3.1"/><line x1="4" y1="12" x2="20" y2="12"/></svg>`,
  code: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
  subscript: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m4 5 8 8"/><path d="m12 5-8 8"/><path d="M20 19h-4c0-1.5.4-2.8 1.4-3.8 1-1 2.6-1.7 2.6-3.2 0-1.1-.9-2-2-2-1.3 0-2 1-2 2"/></svg>`,
  superscript: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m4 19 8-8"/><path d="m12 19-8-8"/><path d="M20 9h-4c0-1.1.4-2 1.4-2.7.9-.7 2.6-1.3 2.6-2.3 0-.8-.9-1.5-2-1.5-1.3 0-2 .8-2 1.5"/></svg>`,
  clearFormat: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 4H6l5.5 8-5.5 8h12"/><line x1="22" y1="2" x2="2" y2="22"/></svg>`,
  
  heading: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 12h12"/><path d="M6 4v16"/><path d="M18 4v16"/></svg>`,
  fontFamily: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>`,
  fontSize: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13V9h10v4"/><path d="M8 9v11"/><path d="M6 20h4"/><path d="M15 7V4h8v3"/><path d="M19 4v12"/><path d="M17 16h4"/></svg>`,
  lineHeight: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="7 3 4 6 7 9"/><polyline points="7 21 4 18 7 15"/><line x1="4" y1="6" x2="4" y2="18"/><line x1="11" y1="6" x2="21" y2="6"/><line x1="11" y1="12" x2="21" y2="12"/><line x1="11" y1="18" x2="21" y2="18"/></svg>`,

  quote: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21c3 0 7-1 7-8V5c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v6c0 4 1.5 8 3 10z"/><path d="M17 21c3 0 7-1 7-8V5c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v6c0 4 1.5 8 3 10z"/></svg>`,
  codeBlock: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="m10 10-2 2 2 2"/><path d="m14 14 2-2-2-2"/></svg>`,
  
  alignLeft: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="21" y1="6" x2="3" y2="6"/><line x1="15" y1="12" x2="3" y2="12"/><line x1="17" y1="18" x2="3" y2="18"/></svg>`,
  alignCenter: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="21" y1="6" x2="3" y2="6"/><line x1="18" y1="12" x2="6" y2="12"/><line x1="21" y1="18" x2="3" y2="18"/></svg>`,
  alignRight: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="12" x2="9" y2="12"/><line x1="21" y1="18" x2="7" y2="18"/></svg>`,
  alignJustify: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="12" x2="3" y2="12"/><line x1="21" y1="18" x2="3" y2="18"/></svg>`,
  
  bulletList: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="20" y2="6"/><line x1="9" y1="12" x2="20" y2="12"/><line x1="9" y1="18" x2="20" y2="18"/><circle cx="4" cy="6" r="2" fill="currentColor"/><circle cx="4" cy="12" r="2" fill="currentColor"/><circle cx="4" cy="18" r="2" fill="currentColor"/></svg>`,
  numberedList: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="10" y1="6" x2="21" y2="6"/><line x1="10" y1="12" x2="21" y2="12"/><line x1="10" y1="18" x2="21" y2="18"/><path d="M4 6h1v4"/><path d="M4 10h2"/><path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/></svg>`,
  taskList: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="6" height="6" rx="1"/><path d="m5 8 1 1 2-2"/><line x1="13" y1="8" x2="21" y2="8"/><rect x="3" y="15" width="6" height="6" rx="1"/><line x1="13" y1="18" x2="21" y2="18"/></svg>`,
  
  indent: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 8 7 12 3 16"/><line x1="21" y1="6" x2="11" y2="6"/><line x1="21" y1="12" x2="11" y2="12"/><line x1="21" y1="18" x2="11" y2="18"/></svg>`,
  outdent: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="7 8 3 12 7 16"/><line x1="21" y1="6" x2="11" y2="6"/><line x1="21" y1="12" x2="11" y2="12"/><line x1="21" y1="18" x2="11" y2="18"/></svg>`,
  
  textColor: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16"/><path d="m6 16 6-12 6 12"/><path d="M8 12h8"/></svg>`,
  bgColor: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m19 11-8-8-8.6 8.6a2 2 0 0 0 0 2.8l5.2 5.2c.8.8 2 .8 2.8 0L19 11Z"/><path d="m5 2 5 5"/><path d="M2 13h15"/><path d="M22 20a2 2 0 1 1-4 0c0-1.6 1.7-2.4 2-4 .3 1.6 2 2.4 2 4Z"/></svg>`,
  
  link: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`,
  unlink: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18.8 15.2 2.6-2.6a5 5 0 0 0-7-7l-1.6 1.6"/><path d="m5.2 8.8-2.6 2.6a5 5 0 0 0 7 7l1.6-1.6"/><line x1="2" y1="2" x2="22" y2="22"/></svg>`,
  image: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`,
  file: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>`,
  video: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2.18" ry="2.18"/><line x1="7" y1="4" x2="7" y2="20"/><line x1="17" y1="4" x2="17" y2="20"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="8" x2="7" y2="8"/><line x1="2" y1="16" x2="7" y2="16"/><line x1="17" y1="8" x2="22" y2="8"/><line x1="17" y1="16" x2="22" y2="16"/></svg>`,
  table: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/><path d="M9 3v18"/><path d="M15 3v18"/></svg>`,
  hr: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/></svg>`,
  
  specialChar: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>`,
  search: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  print: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>`,
  selectAll: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" stroke-dasharray="4 2"/><path d="m9 12 2 2 4-4"/></svg>`,

  sourceCode: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/><line x1="14" y1="4" x2="10" y2="20"/></svg>`,
  fullscreen: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg>`,
  exitFullscreen: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/></svg>`,
  
  close: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  check: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
  alertTriangle: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  info: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
  trash: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>`,
  upload: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>`,
  externalLink: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`,
  edit: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>`,
  chevronDown: `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`,
  download: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
  themeSun: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`,
  themeMoon: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`,
  preview: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,
  help: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  dateTime: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><path d="M12 14v3l2 1"/></svg>`,
  pageBreak: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v4"/><path d="M4 16v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/><path d="M20 8V4a2 2 0 0 0-2-2h-4"/><line x1="2" y1="12" x2="22" y2="12" stroke-dasharray="3 3"/></svg>`
};

// --- Module: src/core/Sanitizer.js ---
/**
 * HTML Sanitizer & Security Defense for D-Lite Editor
 * Provides robust XSS protection, semantic formatting, and clean markup output
 */
class Sanitizer {
  /**
   * Dangerous HTML tags that must never be permitted in editor content
   */
  static FORBIDDEN_TAGS = [
    'script', 'object', 'embed', 'form', 'base', 'meta', 'link', 'style',
    'applet', 'frame', 'frameset', 'template', 'textarea', 'select', 'option', 'optgroup', 'dialog',
    'foreignobject', 'animate', 'set', 'handler', 'listener', 'portal',
    'input:not([type="checkbox"])', 'button:not(.dlite-task-checkbox)'
  ];

  /**
   * Allowed trusted domains for embedded media iframes
   */
  static ALLOWED_IFRAME_SOURCES = [
    /^https:\/\/(www\.)?youtube\.com\/embed\//i,
    /^https:\/\/(www\.)?youtube-nocookie\.com\/embed\//i,
    /^https:\/\/player\.vimeo\.com\/video\//i
  ];

  /**
   * Escape HTML entities to prevent attribute injection
   * @param {string} str 
   * @returns {string}
   */
  static escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>"']/g, c => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[c]));
  }

  /**
   * Cleans and sanitizes HTML content to prevent XSS and remove editor artifacts
   * @param {string} html 
   * @returns {string}
   */
  static clean(html) {
    if (!html || typeof html !== 'string') return '';

    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    // 1. Remove dangerous forbidden tags
    this.FORBIDDEN_TAGS.forEach(selector => {
      doc.body.querySelectorAll(selector).forEach(el => el.remove());
    });

    // 2. Validate and filter iframes
    doc.body.querySelectorAll('iframe').forEach(iframe => {
      const src = (iframe.getAttribute('src') || '').trim();
      const isTrusted = this.ALLOWED_IFRAME_SOURCES.some(pattern => pattern.test(src));
      if (!isTrusted) {
        iframe.remove();
      } else {
        // Enforce secure attributes
        iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-presentation');
        iframe.setAttribute('loading', 'lazy');
      }
    });

    // 3. Inspect all elements and attributes for XSS vectors
    const allElements = doc.body.querySelectorAll('*');
    allElements.forEach(el => {
      // Remove all inline event handlers (on*) and dangerous URIs
      const attrs = Array.from(el.attributes);
      attrs.forEach(attr => {
        const name = attr.name.toLowerCase();
        const rawVal = attr.value;
        const normalizedVal = rawVal.replace(/[\x00-\x20\s]+/g, '').toLowerCase();

        // Strip any on* event handler attribute
        if (name.startsWith('on') || name.startsWith('data-on')) {
          el.removeAttribute(attr.name);
          return;
        }

        // Clean CSS injection and script vectors in inline style
        if (name === 'style') {
          if (/expression\s*\(|javascript:|vbscript:|-moz-binding|behavior:/i.test(rawVal)) {
            el.removeAttribute('style');
            return;
          }
        }

        // Check for URI-based script injection (javascript:, vbscript:, data:text/html)
        if (['href', 'src', 'xlink:href', 'formaction', 'action', 'data'].includes(name)) {
          if (normalizedVal.includes('javascript:') || normalizedVal.includes('vbscript:') || normalizedVal.includes('data:text/html')) {
            el.removeAttribute(attr.name);
            return;
          }

          // For href attributes, only allow safe web schemes: http, https, mailto, tel, or relative/anchor
          if (name === 'href') {
            const isSafeScheme = /^(https?:\/\/|\/|#|mailto:|tel:)/i.test(rawVal.trim());
            if (!isSafeScheme) {
              el.removeAttribute(attr.name);
              return;
            }
          }

          // For img src, disallow dangerous non-image data schemes
          if (name === 'src' && normalizedVal.startsWith('data:')) {
            if (!/^data:image\/(jpeg|png|gif|webp);base64,/i.test(rawVal.trim())) {
              el.removeAttribute(attr.name);
              return;
            }
          }
        }
      });

      // Synchronize input checkboxes checked state with attribute
      if (el.tagName === 'INPUT' && el.getAttribute('type') === 'checkbox') {
        if (el.checked) {
          el.setAttribute('checked', '');
        } else {
          el.removeAttribute('checked');
        }
      }

      // Enforce safe external link attributes
      if (el.tagName === 'A') {
        const href = (el.getAttribute('href') || '').trim();
        if (!href) {
          // Unwrap empty link
          while (el.firstChild) el.parentNode.insertBefore(el.firstChild, el);
          el.remove();
          return;
        }
        if (el.getAttribute('target') === '_blank') {
          el.setAttribute('rel', 'noopener noreferrer');
        }
      }

      // Remove internal temporary editor UI classes
      el.classList.remove('dlite-dropzone-active', 'dlite-selected-img', 'dlite-bubble-hidden');
    });

    return doc.body.innerHTML.trim();
  }

  /**
   * Format HTML with indentation for source code viewer
   * Safely preserves code block whitespace and indentation
   * @param {string} html 
   * @returns {string}
   */
  static formatHTML(html) {
    if (!html) return '';

    // Preserve preformatted code blocks to avoid corrupting user's code indentation
    const preBlocks = [];
    html = html.replace(/<pre\b[^>]*>[\s\S]*?<\/pre>/gi, (match) => {
      preBlocks.push(match);
      return `___DLITE_PRE_BLOCK_${preBlocks.length - 1}___`;
    });

    let formatted = '';
    const reg = /(>)(<)(\/*)/g;
    html = html.replace(reg, '$1\r\n$2$3');
    let pad = 0;

    html.split('\r\n').forEach(node => {
      let indent = 0;
      if (node.match(/.+<\/\w[^>]*>$/)) {
        indent = 0;
      } else if (node.match(/^<\/\w/)) {
        if (pad !== 0) pad -= 1;
      } else if (node.match(/^<\w[^>]*[^\/]>.*$/)) {
        indent = 1;
      } else {
        indent = 0;
      }

      let padding = '';
      for (let i = 0; i < pad; i++) {
        padding += '  ';
      }

      formatted += padding + node + '\r\n';
      pad += indent;
    });

    // Restore preserved pre blocks
    preBlocks.forEach((block, idx) => {
      formatted = formatted.replace(`___DLITE_PRE_BLOCK_${idx}___`, block);
    });

    return formatted.trim();
  }
}

// --- Module: src/core/Selection.js ---
/**
 * Selection & Range Helper for D-Lite Editor
 * Manages caret position, saving/restoring selection, and block/inline node insertion
 */
class SelectionManager {
  constructor(editor) {
    this.editor = editor;
    this.savedRange = null;
  }

  /**
   * Get the current DOM Selection
   */
  getSelection() {
    return window.getSelection();
  }

  /**
   * Get the current Range inside the editor
   */
  getRange() {
    const sel = this.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    const range = sel.getRangeAt(0);
    // Ensure the range is inside the editor canvas
    if (this.editor.canvas && (this.editor.canvas.contains(range.commonAncestorContainer) || this.editor.canvas === range.commonAncestorContainer)) {
      return range;
    }
    return null;
  }

  /**
   * Save the current selection range so it can be restored after modal or toolbar click
   */
  save() {
    const range = this.getRange();
    if (range) {
      this.savedRange = range.cloneRange();
    }
    return this.savedRange;
  }

  /**
   * Restore the previously saved selection range
   */
  restore() {
    if (!this.savedRange) return;
    const sel = this.getSelection();
    sel.removeAllRanges();
    sel.addRange(this.savedRange);
  }

  /**
   * Check if there is currently text selected
   */
  hasSelection() {
    const range = this.getRange();
    return range && !range.collapsed && range.toString().trim().length > 0;
  }

  /**
   * Insert plain text at current caret safely without HTML entity corruption
   * @param {string} text
   */
  insertText(text) {
    const textNode = document.createTextNode(text);
    this.insertNode(textNode);
  }

  /**
   * Insert a standard inline DOM node at current caret
   * @param {Node} node 
   */
  insertNode(node) {
    if (this.savedRange) {
      this.restore();
    }
    let range = this.getRange();
    if (!range) {
      this.editor.canvas.focus();
      range = this.getRange();
    }
    if (!range) {
      this.editor.canvas.appendChild(node);
      return;
    }

    range.deleteContents();
    range.insertNode(node);

    // Move cursor right after the inserted node
    const newRange = document.createRange();
    newRange.setStartAfter(node);
    newRange.collapse(true);
    const sel = this.getSelection();
    sel.removeAllRanges();
    sel.addRange(newRange);
    this.save();
  }

  /**
   * Insert a block-level DOM node (e.g., Table, Tasklist, HR, Figure)
   * Prevents invalid HTML nesting inside <p> and prevents jumping to the top of canvas!
   * @param {Node} node 
   */
  insertBlockNode(node) {
    if (this.savedRange) {
      this.restore();
    }
    let range = this.getRange();
    if (!range) {
      this.editor.canvas.focus();
      range = this.getRange();
    }
    if (!range) {
      this.editor.canvas.appendChild(node);
      return;
    }

    // Find the enclosing block element
    let currentBlock = this.getClosest('p, h1, h2, h3, h4, h5, h6, blockquote, .dlite-task-item, .dlite-table-responsive');

    if (currentBlock && currentBlock !== this.editor.canvas) {
      const text = currentBlock.textContent.trim();
      const isEmpty = !text || currentBlock.innerHTML === '<br>';

      if (isEmpty) {
        // If the current block is empty, replace it directly!
        currentBlock.replaceWith(node);
      } else {
        // If cursor is at the very beginning of the block
        if (range.startOffset === 0 && range.collapsed) {
          currentBlock.parentNode.insertBefore(node, currentBlock);
        } else {
          // Insert right after current block
          currentBlock.parentNode.insertBefore(node, currentBlock.nextSibling);
        }
      }
    } else {
      // Append right at current range or canvas end
      range.deleteContents();
      range.insertNode(node);
    }

    this.save();
  }

  /**
   * Insert HTML string at the current cursor
   * @param {string} html 
   */
  insertHTML(html) {
    const fragment = document.createRange().createContextualFragment(html);
    const lastNode = fragment.lastChild;
    this.insertNode(fragment);
    return lastNode;
  }

  /**
   * Find closest element matching selector from current selection
   * @param {string} selector 
   * @returns {HTMLElement|null}
   */
  getClosest(selector) {
    const range = this.getRange() || this.savedRange;
    if (!range) return null;
    let node = range.commonAncestorContainer;
    if (node.nodeType === Node.TEXT_NODE) node = node.parentNode;
    if (node && node.closest) {
      const match = node.closest(selector);
      if (match && this.editor.canvas.contains(match)) {
        return match;
      }
    }
    return null;
  }

  /**
   * Check if formatting tag/style is currently active at cursor
   * @param {string} command 
   * @returns {boolean}
   */
  isFormatActive(command) {
    try {
      return document.queryCommandState(command);
    } catch {
      return false;
    }
  }
}

// --- Module: src/core/History.js ---
/**
 * History (Undo / Redo) Manager for D-Lite Editor
 */
class HistoryManager {
  constructor(editor, maxStack = 50) {
    this.editor = editor;
    this.maxStack = maxStack;
    this.undoStack = [];
    this.redoStack = [];
    this.debounceTimer = null;
    this.lastContent = '';
  }

  /**
   * Save snapshot of current editor state
   * @param {boolean} [immediate=false]
   */
  record(immediate = false) {
    if (immediate) {
      this._saveSnapshot();
    } else {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = setTimeout(() => {
        this._saveSnapshot();
      }, 350);
    }
  }

  _saveSnapshot() {
    const content = this.editor.getHTML();
    if (content === this.lastContent) return;

    this.undoStack.push(content);
    if (this.undoStack.length > this.maxStack) {
      this.undoStack.shift();
    }
    this.redoStack = []; // Clear redo stack on new action
    this.lastContent = content;
  }

  undo() {
    if (this.undoStack.length === 0) return;

    const current = this.editor.getHTML();
    let prev = this.undoStack.pop();

    // If popped snapshot matches current content, take the previous one
    if (prev === current && this.undoStack.length > 0) {
      prev = this.undoStack.pop();
    }
    if (prev === current) return;

    this.redoStack.push(current);
    this.lastContent = prev;
    this.editor.canvas.innerHTML = prev;
    this.editor._onContentChanged();
  }

  redo() {
    if (this.redoStack.length === 0) return;

    const next = this.redoStack.pop();
    this.undoStack.push(this.editor.getHTML());
    this.lastContent = next;
    this.editor.canvas.innerHTML = next;
    this.editor._onContentChanged();
  }

  canUndo() {
    return this.undoStack.length > 0;
  }

  canRedo() {
    return this.redoStack.length > 0;
  }

  clear() {
    this.undoStack = [];
    this.redoStack = [];
    this.lastContent = '';
  }
}

// --- Module: src/ui/Toast.js ---
/**
 * DLiteToast - Modern Toast Notification Manager
 * Completely replaces browser native alert()
 */
class DLiteToast {
  constructor() {
    this.container = null;
    this.toasts = [];
    this._ensureContainer();
  }

  _ensureContainer() {
    let container = document.getElementById('dlite-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'dlite-toast-container';
      container.className = 'dlite-toast-container';
      document.body.appendChild(container);
    }
    this.container = container;
  }

  /**
   * Show a toast notification
   * @param {Object} options 
   * @param {string} options.type - 'success' | 'error' | 'warning' | 'info'
   * @param {string} options.title - Notification title
   * @param {string} options.message - Notification message body
   * @param {number} [options.duration=4000] - Duration in ms (0 for persistent)
   * @param {string} [options.actionLabel] - Optional action button
   * @param {Function} [options.onAction] - Action callback
   */
  show({ type = 'info', title = '', message = '', duration = 4000, actionLabel, onAction }) {
    this._ensureContainer();

    const toast = document.createElement('div');
    toast.className = `dlite-toast dlite-toast-${type}`;

    let iconSvg = Icons.info;
    if (type === 'success') iconSvg = Icons.check;
    else if (type === 'error' || type === 'warning') iconSvg = Icons.alertTriangle;

    const actionHtml = actionLabel 
      ? `<button class="dlite-toast-action" type="button">${actionLabel}</button>` 
      : '';

    toast.innerHTML = `
      <div class="dlite-toast-icon">${iconSvg}</div>
      <div class="dlite-toast-content">
        ${title ? `<div class="dlite-toast-title">${title}</div>` : ''}
        <div class="dlite-toast-message">${message}</div>
      </div>
      ${actionHtml}
      <button class="dlite-toast-close" type="button" aria-label="Tutup notifikasi">${Icons.close}</button>
      ${duration > 0 ? `<div class="dlite-toast-progress" style="animation-duration: ${duration}ms"></div>` : ''}
    `;

    // Handle close button
    const closeBtn = toast.querySelector('.dlite-toast-close');
    closeBtn.addEventListener('click', () => this.dismiss(toast));

    // Handle action button
    if (actionLabel && onAction) {
      const actionBtn = toast.querySelector('.dlite-toast-action');
      actionBtn.addEventListener('click', () => {
        onAction();
        this.dismiss(toast);
      });
    }

    this.container.appendChild(toast);

    // Trigger enter animation
    requestAnimationFrame(() => {
      toast.classList.add('dlite-toast-visible');
    });

    if (duration > 0) {
      const timeoutId = setTimeout(() => {
        this.dismiss(toast);
      }, duration);
      toast._timeoutId = timeoutId;

      // Pause on hover
      toast.addEventListener('mouseenter', () => {
        clearTimeout(toast._timeoutId);
        const progress = toast.querySelector('.dlite-toast-progress');
        if (progress) progress.style.animationPlayState = 'paused';
      });

      toast.addEventListener('mouseleave', () => {
        const progress = toast.querySelector('.dlite-toast-progress');
        if (progress) progress.style.animationPlayState = 'running';
        toast._timeoutId = setTimeout(() => this.dismiss(toast), 1500);
      });
    }

    return toast;
  }

  success(message, title = 'Berhasil') {
    return this.show({ type: 'success', title, message });
  }

  error(message, title = 'Terjadi Kesalahan') {
    return this.show({ type: 'error', title, message, duration: 6000 });
  }

  warning(message, title = 'Peringatan') {
    return this.show({ type: 'warning', title, message, duration: 5000 });
  }

  info(message, title = 'Informasi') {
    return this.show({ type: 'info', title, message });
  }

  dismiss(toast) {
    if (!toast || !toast.parentNode) return;
    toast.classList.remove('dlite-toast-visible');
    toast.classList.add('dlite-toast-leaving');
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 250);
  }
}

const toast = new DLiteToast();

// --- Module: src/ui/Modal.js ---
/**
 * DLiteModal - Modern Modal & Custom Dialog Manager
 * Completely replaces window.alert(), window.confirm(), and window.prompt()
 */
class DLiteModal {
  constructor() {
    this.activeModals = [];
    this._handleKeyDown = this._handleKeyDown.bind(this);
    document.addEventListener('keydown', this._handleKeyDown);
  }

  _handleKeyDown(e) {
    if (e.key === 'Escape' && this.activeModals.length > 0) {
      const topModal = this.activeModals[this.activeModals.length - 1];
      if (topModal && topModal.options.closeOnEscape !== false) {
        this.close(topModal);
      }
    }
  }

  /**
   * Open a custom modal
   * @param {Object} options
   * @param {string} options.title - Modal title
   * @param {string|HTMLElement} options.content - Modal body content
   * @param {Array<Object>} [options.buttons] - Action buttons in footer
   * @param {string} [options.width='480px'] - Custom width
   * @param {boolean} [options.closeOnBackdrop=true] - Close when clicking outside
   * @param {boolean} [options.closeOnEscape=true] - Close on ESC key
   * @returns {Object} Modal instance controller
   */
  open(options = {}) {
    const {
      title = '',
      content = '',
      buttons = [],
      width = '520px',
      closeOnBackdrop = true,
      customClass = ''
    } = options;

    const overlay = document.createElement('div');
    overlay.className = `dlite-modal-overlay ${customClass}`;

    const dialog = document.createElement('div');
    dialog.className = 'dlite-modal-dialog';
    dialog.style.maxWidth = width;

    // Header
    const header = document.createElement('div');
    header.className = 'dlite-modal-header';
    header.innerHTML = `
      <h3 class="dlite-modal-title"></h3>
      <button class="dlite-modal-close" type="button" aria-label="Tutup">${Icons.close}</button>
    `;
    header.querySelector('.dlite-modal-title').textContent = title;

    // Body
    const body = document.createElement('div');
    body.className = 'dlite-modal-body';
    if (typeof content === 'string') {
      body.innerHTML = content;
    } else if (content instanceof HTMLElement) {
      body.appendChild(content);
    }

    // Footer
    const footer = document.createElement('div');
    footer.className = 'dlite-modal-footer';

    const modalObj = { overlay, dialog, options, close: () => this.close(modalObj) };

    if (buttons.length > 0) {
      buttons.forEach(btn => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `dlite-btn dlite-btn-${btn.type || 'secondary'} ${btn.class || ''}`;
        button.textContent = btn.text || 'OK';
        button.addEventListener('click', () => {
          if (btn.onClick) {
            const shouldClose = btn.onClick(modalObj, body);
            if (shouldClose !== false) this.close(modalObj);
          } else {
            this.close(modalObj);
          }
        });
        footer.appendChild(button);
      });
    }

    dialog.appendChild(header);
    dialog.appendChild(body);
    if (buttons.length > 0) {
      dialog.appendChild(footer);
    }
    overlay.appendChild(dialog);

    // Event listeners
    header.querySelector('.dlite-modal-close').addEventListener('click', () => {
      if (options.onClose) options.onClose();
      this.close(modalObj);
    });

    if (closeOnBackdrop) {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          if (options.onClose) options.onClose();
          this.close(modalObj);
        }
      });
    }

    document.body.appendChild(overlay);
    this.activeModals.push(modalObj);

    // Animate in
    requestAnimationFrame(() => {
      overlay.classList.add('dlite-modal-visible');
      // Focus first input if any
      const input = body.querySelector('input, textarea, select');
      if (input) input.focus();
    });

    return modalObj;
  }

  close(modalObj) {
    if (!modalObj || !modalObj.overlay) return;
    const { overlay } = modalObj;
    overlay.classList.remove('dlite-modal-visible');
    overlay.classList.add('dlite-modal-leaving');

    this.activeModals = this.activeModals.filter(m => m !== modalObj);

    setTimeout(() => {
      if (overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    }, 220);
  }

  /**
   * Modern replacement for window.confirm()
   * @param {Object} options
   * @returns {Promise<boolean>}
   */
  confirm({
    title = 'Konfirmasi',
    message = 'Apakah Anda yakin ingin melanjutkan tindakan ini?',
    confirmText = 'Lanjutkan',
    cancelText = 'Batal',
    isDestructive = false
  } = {}) {
    return new Promise((resolve) => {
      const content = document.createElement('div');
      content.className = 'dlite-confirm-content';
      content.innerHTML = `
        <div class="dlite-confirm-icon ${isDestructive ? 'dlite-confirm-danger' : ''}">
          ${Icons.alertTriangle}
        </div>
        <div class="dlite-confirm-text">
          <p class="dlite-confirm-message"></p>
        </div>
      `;
      content.querySelector('.dlite-confirm-message').textContent = message;

      this.open({
        title,
        content,
        width: '420px',
        closeOnBackdrop: false,
        onClose: () => resolve(false),
        buttons: [
          {
            text: cancelText,
            type: 'secondary',
            onClick: () => {
              resolve(false);
              return true;
            }
          },
          {
            text: confirmText,
            type: isDestructive ? 'danger' : 'primary',
            onClick: () => {
              resolve(true);
              return true;
            }
          }
        ]
      });
    });
  }

  /**
   * Modern replacement for window.prompt()
   * @param {Object} options
   * @returns {Promise<string|null>}
   */
  prompt({
    title = 'Input Data',
    message = '',
    defaultValue = '',
    placeholder = 'Masukkan nilai...',
    confirmText = 'Simpan',
    cancelText = 'Batal'
  } = {}) {
    return new Promise((resolve) => {
      const content = document.createElement('div');
      content.className = 'dlite-prompt-content';
      content.innerHTML = `
        <p class="dlite-prompt-message"></p>
        <input type="text" class="dlite-input dlite-prompt-input" />
      `;

      const msgEl = content.querySelector('.dlite-prompt-message');
      if (message) {
        msgEl.textContent = message;
      } else {
        msgEl.remove();
      }

      const input = content.querySelector('.dlite-prompt-input');
      input.value = defaultValue;
      input.placeholder = placeholder;

      const modal = this.open({
        title,
        content,
        width: '440px',
        closeOnBackdrop: false,
        onClose: () => resolve(null),
        buttons: [
          {
            text: cancelText,
            type: 'secondary',
            onClick: () => {
              resolve(null);
              return true;
            }
          },
          {
            text: confirmText,
            type: 'primary',
            onClick: () => {
              resolve(input.value);
              return true;
            }
          }
        ]
      });

      // Submit on Enter
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          resolve(input.value);
          this.close(modal);
        }
      });
    });
  }
}

const modal = new DLiteModal();

// --- Module: src/plugins/Formatting.js ---
/**
 * Formatting Plugin for D-Lite Editor
 * Text styles, typography headings, alignments, lists, checklists, colors, fonts, and print
 */
class Formatting {
  constructor(editor) {
    this.editor = editor;
  }

  exec(command, value = null) {
    this.editor.canvas.focus();
    document.execCommand(command, false, value);
    this.editor._onContentChanged();
    this.editor.history.record();
    this.editor.toolbar?.updateActiveStates();
  }

  bold() { this.exec('bold'); }
  italic() { this.exec('italic'); }
  underline() { this.exec('underline'); }
  strike() { this.exec('strikeThrough'); }
  subscript() { this.exec('subscript'); }
  superscript() { this.exec('superscript'); }

  clearFormat() {
    this.exec('removeFormat');
    this.removeBgColor();
    this.formatBlock('p');
  }

  formatBlock(tag) {
    this.editor.canvas.focus();
    document.execCommand('formatBlock', false, `<${tag}>`);
    this.editor._onContentChanged();
    this.editor.history.record();
  }

  blockquote() {
    this.editor.canvas.focus();
    const existing = this.editor.selection.getClosest('blockquote');
    if (existing) {
      const p = document.createElement('p');
      p.innerHTML = existing.innerHTML;
      existing.replaceWith(p);
      const range = document.createRange();
      range.selectNodeContents(p);
      range.collapse(false);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      this.editor.selection.save();
      this.editor._onContentChanged();
      this.editor.history.record(true);
    } else {
      this.formatBlock('blockquote');
    }
    this.editor.toolbar?.updateActiveStates();
  }

  /**
   * Smart alignment for text, images, and file attachment cards
   */
  align(alignment) {
    // 1. Check if an image is currently selected
    if (this.editor.plugins.image && this.editor.plugins.image.selectedImage) {
      const figure = this.editor.plugins.image.selectedImage.closest('figure') || this.editor.plugins.image.selectedImage;
      figure.classList.remove('dlite-align-left', 'dlite-align-center', 'dlite-align-right');
      figure.classList.add(`dlite-align-${alignment}`);
      this.editor.plugins.image.positionBubble();
      this.editor._onContentChanged();
      this.editor.history.record(true);
      return;
    }

    // 2. Check if cursor is on/inside a file container or image figure
    const fileContainer = this.editor.selection.getClosest('.dlite-file-container');
    if (fileContainer) {
      fileContainer.classList.remove('dlite-align-left', 'dlite-align-center', 'dlite-align-right');
      fileContainer.classList.add(`dlite-align-${alignment}`);
      this.editor._onContentChanged();
      this.editor.history.record(true);
      return;
    }

    const figure = this.editor.selection.getClosest('.dlite-media-figure');
    if (figure) {
      figure.classList.remove('dlite-align-left', 'dlite-align-center', 'dlite-align-right');
      figure.classList.add(`dlite-align-${alignment}`);
      this.editor._onContentChanged();
      this.editor.history.record(true);
      return;
    }

    // 3. Fallback to native text justify command
    const cmdMap = {
      left: 'justifyLeft',
      center: 'justifyCenter',
      right: 'justifyRight',
      justify: 'justifyFull'
    };
    if (cmdMap[alignment]) {
      this.exec(cmdMap[alignment]);
    }
  }

  bulletList() { this.exec('insertUnorderedList'); }
  numberedList() { this.exec('insertOrderedList'); }

  /**
   * Interactive Checklist / Tasklist
   * Inserts cleanly at current caret position without jumping to the top!
   */
  taskList() {
    const taskItem = document.createElement('div');
    taskItem.className = 'dlite-task-item';
    taskItem.innerHTML = `
      <input type="checkbox" class="dlite-task-checkbox" contenteditable="false" />
      <span class="dlite-task-text" contenteditable="true">Tugas baru...</span>
    `;

    // Insert block at exact caret position
    this.editor.selection.insertBlockNode(taskItem);

    // Focus inside task text
    const textSpan = taskItem.querySelector('.dlite-task-text');
    if (textSpan) {
      const range = document.createRange();
      range.selectNodeContents(textSpan);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      this.editor.selection.save();
    }

    this.editor._onContentChanged();
    this.editor.history.record(true);
  }

  indent() { this.exec('indent'); }
  outdent() { this.exec('outdent'); }

  horizontalRule() {
    const hr = document.createElement('hr');
    hr.className = 'dlite-hr';
    this.editor.selection.insertBlockNode(hr);

    const p = document.createElement('p');
    p.innerHTML = '<br>';
    hr.after(p);

    const range = document.createRange();
    range.setStart(p, 0);
    range.collapse(true);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    this.editor.selection.save();

    this.editor._onContentChanged();
    this.editor.history.record(true);
  }

  pageBreak() {
    this.editor.canvas.focus();
    const hr = document.createElement('div');
    hr.className = 'dlite-page-break';
    hr.setAttribute('contenteditable', 'false');
    hr.innerHTML = `<span><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v4"/><path d="M4 16v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/><path d="M20 8V4a2 2 0 0 0-2-2h-4"/><line x1="2" y1="12" x2="22" y2="12" stroke-dasharray="3 3"/></svg> Pemisah Halaman (Page Break)</span>`;

    this.editor.selection.insertBlockNode(hr);

    const p = document.createElement('p');
    p.innerHTML = '<br>';
    hr.after(p);

    const range = document.createRange();
    range.setStart(p, 0);
    range.collapse(true);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    this.editor.selection.save();

    this.editor._onContentChanged();
    this.editor.history.record(true);
  }

  insertDateTime() {
    this.editor.canvas.focus();
    const now = new Date();
    const optionsDate = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const dateStr = now.toLocaleDateString('id-ID', optionsDate);
    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    const fullStr = `${dateStr}, ${timeStr} WIB`;

    const span = document.createElement('span');
    span.className = 'dlite-datetime-badge';
    span.textContent = fullStr;

    this.editor.selection.insertNode(span);

    const space = document.createTextNode(' ');
    span.after(space);

    const range = document.createRange();
    range.setStartAfter(space);
    range.collapse(true);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    this.editor.selection.save();

    this.editor._onContentChanged();
    this.editor.history.record(true);
  }

  inlineCode() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const range = sel.getRangeAt(0);
    const selectedText = range.toString();

    if (selectedText) {
      const code = document.createElement('code');
      code.className = 'dlite-inline-code';
      code.textContent = selectedText;
      range.deleteContents();
      range.insertNode(code);
      this.editor._onContentChanged();
      this.editor.history.record(true);
    }
  }

  textColor(color) {
    if (!color || color === 'transparent') {
      this.exec('foreColor', 'inherit');
      return;
    }
    this.exec('foreColor', color);
  }

  /**
   * Highlight color with support for clear / transparent
   */
  bgColor(color) {
    if (!color || color === 'transparent') {
      this.removeBgColor();
      return;
    }
    this.exec('hiliteColor', color);
  }

  removeBgColor() {
    this.editor.canvas.focus();
    const range = this.editor.selection.getRange();
    if (!range) return;

    document.execCommand('hiliteColor', false, 'transparent');

    // Clean up any remaining background inline styles from selection nodes
    const ancestor = range.commonAncestorContainer;
    const root = ancestor.nodeType === Node.ELEMENT_NODE ? ancestor : ancestor.parentElement;
    if (root) {
      const styledSpans = root.querySelectorAll('span[style*="background"], font[style*="background"], mark');
      styledSpans.forEach(el => {
        el.style.backgroundColor = '';
        if (!el.getAttribute('style')) {
          while (el.firstChild) el.parentNode.insertBefore(el.firstChild, el);
          el.remove();
        }
      });
    }

    this.editor._onContentChanged();
    this.editor.history.record(true);
  }

  fontFamily(font) {
    this.exec('fontName', font);
  }

  fontSize(sizePx) {
    this.editor.canvas.focus();
    const range = this.editor.selection.getRange();
    if (!range) return;

    if (!range.collapsed) {
      const span = document.createElement('span');
      span.style.fontSize = sizePx;
      span.appendChild(range.extractContents());
      range.insertNode(span);
    } else {
      const block = this.editor.selection.getClosest('p, h1, h2, h3, h4, h5, h6, li, div');
      if (block) {
        block.style.fontSize = sizePx;
      }
    }
    this.editor._onContentChanged();
    this.editor.history.record();
  }

  lineHeight(val) {
    this.editor.canvas.focus();
    const block = this.editor.selection.getClosest('p, h1, h2, h3, h4, h5, h6, li, blockquote, div');
    if (block) {
      block.style.lineHeight = val;
      this.editor._onContentChanged();
      this.editor.history.record();
    }
  }

  selectAll() {
    this.editor.canvas.focus();
    document.execCommand('selectAll', false, null);
  }

  print() {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.warning('Jendela pencetakan diblokir oleh browser. Izinkan pop-up untuk mencetak dokumen.');
      return;
    }
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Cetak Dokumen - D-Lite Editor</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; padding: 40px; color: #111; }
          img { max-width: 100%; height: auto; }
          table { width: 100%; border-collapse: collapse; margin: 1em 0; }
          th, td { border: 1px solid #ddd; padding: 8px 12px; }
          th { background: #f5f5f5; }
          blockquote { border-left: 4px solid #3b82f6; padding-left: 14px; margin: 1em 0; color: #555; }
          pre { background: #f8f9fa; border: 1px solid #e9ecef; padding: 12px; border-radius: 6px; }
          .dlite-file-card { border: 1px solid #ccc; padding: 10px; border-radius: 6px; display: inline-block; }
        </style>
      </head>
      <body>
        ${this.editor.getContent()}
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  }
}

// --- Module: src/plugins/Uploader.js ---
/**
 * Uploader Plugin for D-Lite Editor
 * Handles Drag & Drop, Clipboard Paste, and File/Image Upload with Live Progress Bars
 */
class Uploader {
  constructor(editor, options = {}) {
    this.editor = editor;
    this.options = Object.assign({
      endpoint: '/api/upload',
      fieldName: 'file',
      headers: {},
      maxFileSize: 10 * 1024 * 1024, // 10 MB
      allowedImageTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'],
      allowedFileTypes: ['application/pdf', 'application/zip', '.docx', '.xlsx', '.txt'],
      customUploader: null
    }, options);

    this.init();
  }

  init() {
    this._initDropzone();
    this._initPasteHandler();
  }

  /**
   * Initialize Drag and Drop into editor canvas
   */
  _initDropzone() {
    const canvas = this.editor.canvas;

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
      canvas.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
      }, false);
    });

    canvas.addEventListener('dragover', () => {
      canvas.classList.add('dlite-dropzone-active');
    });

    ['dragleave', 'drop'].forEach(eventName => {
      canvas.addEventListener(eventName, () => {
        canvas.classList.remove('dlite-dropzone-active');
      });
    });

    canvas.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      if (files && files.length > 0) {
        // Place cursor at drop point
        if (document.caretRangeFromPoint) {
          const range = document.caretRangeFromPoint(e.clientX, e.clientY);
          if (range) {
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            this.editor.selection.save();
          }
        }
        Array.from(files).forEach(file => this.upload(file));
      }
    });
  }

  /**
   * Handle pasting images from clipboard
   */
  _initPasteHandler() {
    this.editor.canvas.addEventListener('paste', (e) => {
      const clipboardData = e.clipboardData || window.clipboardData;
      if (!clipboardData) return;

      const items = clipboardData.items;

      // 1. Check if image file exists in clipboard
      if (items) {
        for (let i = 0; i < items.length; i++) {
          if (items[i].type.indexOf('image') !== -1) {
            const file = items[i].getAsFile();
            if (file) {
              e.preventDefault();
              this.upload(file);
              return;
            }
          }
        }
      }

      // 2. If rich HTML is being pasted from web or external documents, sanitize it!
      const html = clipboardData.getData('text/html');
      if (html) {
        e.preventDefault();
        const clean = Sanitizer.clean(html);
        this.editor.selection.insertHTML(clean);
        this.editor._onContentChanged();
        this.editor.history.record(true);
      }
    });
  }

  /**
   * Validate file size and type
   */
  validate(file) {
    if (file.size > this.options.maxFileSize) {
      const maxMb = (this.options.maxFileSize / (1024 * 1024)).toFixed(0);
      toast.error(`Ukuran berkas "${file.name}" melebihi batas maksimum ${maxMb}MB.`);
      return false;
    }

    const isImage = file.type.startsWith('image/');
    if (isImage) {
      if (this.options.allowedImageTypes.length > 0 && !this.options.allowedImageTypes.includes(file.type)) {
        toast.error(`Format gambar "${file.name}" tidak didukung.`);
        return false;
      }
    }
    return true;
  }

  /**
   * Upload a file or image
   * @param {File} file 
   */
  async upload(file) {
    if (!this.validate(file)) return;

    const isImage = file.type.startsWith('image/');
    const placeholderId = 'dlite-upload-' + Date.now() + '-' + Math.random().toString(36).substr(2, 6);

    // Create live progress placeholder in canvas
    this._insertPlaceholder(placeholderId, file, isImage);

    try {
      let result;
      if (typeof this.options.customUploader === 'function') {
        result = await this.options.customUploader(file, (percent) => {
          this._updateProgress(placeholderId, percent);
        });
      } else {
        result = await this._defaultHttpUpload(file, (percent) => {
          this._updateProgress(placeholderId, percent);
        });
      }

      this._handleSuccess(placeholderId, result, file, isImage);
    } catch (err) {
      this._handleError(placeholderId, err, file);
    }
  }

  /**
   * Insert placeholder element with progress bar into canvas
   */
  _insertPlaceholder(id, file, isImage) {
    const placeholder = document.createElement('div');
    placeholder.id = id;
    placeholder.className = `dlite-upload-placeholder ${isImage ? 'is-image' : 'is-file'}`;
    placeholder.contentEditable = 'false';

    const safeFileName = Sanitizer.escapeHtml(file.name);
    const fileSizeFormatted = (file.size / 1024).toFixed(1) + ' KB';

    placeholder.innerHTML = `
      <div class="dlite-upload-inner">
        <div class="dlite-upload-spinner"></div>
        <div class="dlite-upload-info">
          <span class="dlite-upload-name">${safeFileName}</span>
          <span class="dlite-upload-size">(${fileSizeFormatted})</span>
          <span class="dlite-upload-percent">0%</span>
        </div>
        <div class="dlite-upload-bar-track">
          <div class="dlite-upload-bar-fill" style="width: 0%"></div>
        </div>
      </div>
    `;

    this.editor.selection.insertBlockNode(placeholder);
    this.editor._onContentChanged();
  }

  _updateProgress(id, percent) {
    const el = document.getElementById(id);
    if (!el) return;
    const clamped = Math.min(100, Math.max(0, Math.round(percent)));
    const percentText = el.querySelector('.dlite-upload-percent');
    const barFill = el.querySelector('.dlite-upload-bar-fill');
    if (percentText) percentText.textContent = `${clamped}%`;
    if (barFill) barFill.style.width = `${clamped}%`;
  }

  _handleSuccess(id, result, file, isImage) {
    const placeholder = document.getElementById(id);
    if (!placeholder) return;

    let url = result?.url || result?.data?.url || (file ? URL.createObjectURL(file) : '');
    if (!/^(https?:\/\/|\/|blob:)/i.test(url.trim())) {
      url = '#';
    }

    if (isImage) {
      const figure = document.createElement('figure');
      figure.className = 'dlite-media-figure dlite-align-center';
      
      const img = document.createElement('img');
      img.src = url;
      img.alt = file.name || 'Gambar';
      img.className = 'dlite-media-image';
      
      const figcaption = document.createElement('figcaption');
      figcaption.className = 'dlite-media-caption';
      figcaption.textContent = '';
      figcaption.setAttribute('data-placeholder', 'Tuliskan keterangan gambar di sini (opsional)...');

      figure.appendChild(img);
      figure.appendChild(figcaption);

      placeholder.replaceWith(figure);
      toast.success(`Gambar "${file.name}" berhasil diunggah.`);
    } else {
      // Create file attachment card
      const card = this.editor.plugins.file?.createFileCard({
        url,
        name: file.name,
        size: file.size
      });

      if (card) {
        placeholder.replaceWith(card);
      } else {
        placeholder.remove();
      }
      toast.success(`Berkas "${file.name}" berhasil diunggah.`);
    }

    this.editor._onContentChanged();
    this.editor.history.record(true);
  }

  _handleError(id, err, file) {
    const placeholder = document.getElementById(id);
    const errorMsg = err?.message || 'Gagal mengunggah berkas.';
    const safeFileName = Sanitizer.escapeHtml(file.name);
    const safeErrorMsg = Sanitizer.escapeHtml(errorMsg);
    toast.error(errorMsg, `Upload Gagal: ${file.name}`);

    if (placeholder) {
      placeholder.innerHTML = `
        <div class="dlite-upload-inner dlite-upload-failed">
          <span class="dlite-upload-fail-icon">${Icons.alertTriangle}</span>
          <div class="dlite-upload-fail-text">
            <strong>Gagal: ${safeFileName}</strong>
            <small>${safeErrorMsg}</small>
          </div>
          <button class="dlite-btn dlite-btn-sm dlite-btn-secondary" type="button">Hapus</button>
        </div>
      `;
      placeholder.querySelector('button').addEventListener('click', () => {
        placeholder.remove();
        this.editor._onContentChanged();
      });
    }
  }

  /**
   * Default XMLHttpRequest upload with progress event
   */
  _defaultHttpUpload(file, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', this.options.endpoint, true);

      // Add headers
      if (this.options.headers) {
        Object.entries(this.options.headers).forEach(([key, val]) => {
          xhr.setRequestHeader(key, val);
        });
      }

      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          const percent = (e.loaded / e.total) * 100;
          onProgress(percent);
        }
      };

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const json = JSON.parse(xhr.responseText);
            if (json.success !== false) {
              resolve(json);
            } else {
              reject(new Error(json.message || 'Server menolak berkas'));
            }
          } catch {
            resolve({ url: URL.createObjectURL(file) });
          }
        } else {
          reject(new Error(`Server merespons kode HTTP ${xhr.status}`));
        }
      };

      xhr.onerror = () => reject(new Error('Koneksi jaringan terputus saat upload'));

      const formData = new FormData();
      formData.append(this.options.fieldName, file);
      xhr.send(formData);
    });
  }
}

// --- Module: src/plugins/ImagePlugin.js ---
/**
 * Image Plugin for D-Lite Editor
 * Image insertion modal, floating image bubble toolbar, resizing & alignment
 */
class ImagePlugin {
  constructor(editor) {
    this.editor = editor;
    this.selectedImage = null;
    this.bubble = null;
    this.resizer = null;
    this.init();
  }

  init() {
    this._createImageBubble();
    this._initClickWatcher();
  }

  /**
   * Open the custom Image Insertion Modal (strictly NO native alerts/prompts)
   */
  openModal() {
    this.editor.selection.save();

    const content = document.createElement('div');
    content.className = 'dlite-media-modal-content';
    content.innerHTML = `
      <div class="dlite-tabs">
        <button class="dlite-tab-btn active" data-tab="upload" type="button">Upload dari Komputer</button>
        <button class="dlite-tab-btn" data-tab="url" type="button">URL Gambar Web</button>
      </div>
      
      <div class="dlite-tab-pane active" id="tab-upload">
        <div class="dlite-drop-area" id="dlite-image-file-drop">
          <div class="dlite-drop-icon">${Icons.upload}</div>
          <p class="dlite-drop-text">Pilih atau seret gambar ke sini</p>
          <small class="dlite-drop-sub">JPG, PNG, WebP, GIF, SVG (Maks. 10MB)</small>
          <input type="file" id="dlite-image-input" accept="image/*" class="dlite-hidden-input" />
          <button class="dlite-btn dlite-btn-primary dlite-btn-sm" type="button" id="dlite-browse-img-btn">Pilih Gambar</button>
        </div>
      </div>

      <div class="dlite-tab-pane" id="tab-url">
        <div class="dlite-form-group">
          <label class="dlite-label">Tautan / URL Gambar</label>
          <input type="url" id="dlite-image-url-input" class="dlite-input" placeholder="https://contoh.com/gambar.jpg" />
        </div>
        <div class="dlite-form-group">
          <label class="dlite-label">Teks Alternatif (Alt Text)</label>
          <input type="text" id="dlite-image-alt-input" class="dlite-input" placeholder="Deskripsi gambar untuk aksesibilitas" />
        </div>
      </div>
    `;

    // Tab switching logic
    const tabs = content.querySelectorAll('.dlite-tab-btn');
    const panes = content.querySelectorAll('.dlite-tab-pane');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        panes.forEach(p => p.classList.remove('active'));
        tab.classList.add('active');
        content.querySelector(`#tab-${tab.dataset.tab}`).classList.add('active');
      });
    });

    const fileInput = content.querySelector('#dlite-image-input');
    const browseBtn = content.querySelector('#dlite-browse-img-btn');
    const dropArea = content.querySelector('#dlite-image-file-drop');

    browseBtn.addEventListener('click', () => fileInput.click());
    dropArea.addEventListener('click', (e) => {
      if (e.target !== browseBtn) fileInput.click();
    });

    const modalInstance = modal.open({
      title: 'Sisipkan Gambar',
      content,
      width: '480px',
      buttons: [
        {
          text: 'Batal',
          type: 'secondary',
          onClick: () => true
        },
        {
          text: 'Sisipkan',
          type: 'primary',
          onClick: () => {
            const activeTab = content.querySelector('.dlite-tab-btn.active').dataset.tab;
            if (activeTab === 'url') {
              const url = content.querySelector('#dlite-image-url-input').value.trim();
              const alt = content.querySelector('#dlite-image-alt-input').value.trim();
              if (!url) {
                toast.warning('Silakan masukkan URL gambar.');
                return false;
              }
              this.insertImageUrl(url, alt);
              return true;
            } else {
              if (fileInput.files && fileInput.files[0]) {
                this.editor.plugins.uploader.upload(fileInput.files[0]);
                return true;
              }
              toast.warning('Silakan pilih berkas gambar yang ingin diunggah.');
              return false;
            }
          }
        }
      ]
    });

    fileInput.addEventListener('change', () => {
      if (fileInput.files && fileInput.files[0]) {
        modalInstance.close();
        this.editor.plugins.uploader.upload(fileInput.files[0]);
      }
    });
  }

  insertImageUrl(url, alt = '') {
    const dangerous = /^(javascript|vbscript|data:(?!image\/)|file:)/i;
    if (dangerous.test(url.replace(/\s+/g, ''))) {
      toast.error('URL gambar tidak diizinkan demi keamanan.');
      return;
    }

    this.editor.selection.restore();
    const figure = document.createElement('figure');
    figure.className = 'dlite-media-figure dlite-align-center';

    const img = document.createElement('img');
    img.src = url;
    img.alt = alt || 'Gambar';
    img.className = 'dlite-media-image';

    const caption = document.createElement('figcaption');
    caption.className = 'dlite-media-caption';
    caption.textContent = '';
    caption.setAttribute('data-placeholder', 'Tuliskan keterangan gambar di sini (opsional)...');

    figure.appendChild(img);
    figure.appendChild(caption);

    this.editor.selection.insertBlockNode(figure);
    this.editor._onContentChanged();
    this.editor.history.record(true);
    toast.success('Gambar berhasil disisipkan.');
  }

  /**
   * Floating Image Bubble Toolbar
   */
  _createImageBubble() {
    this.bubble = document.createElement('div');
    this.bubble.className = 'dlite-image-bubble dlite-bubble-hidden';
    this.bubble.innerHTML = `
      <div class="dlite-bubble-group">
        <button type="button" class="dlite-bubble-btn" data-align="left" title="Rata Kiri">${Icons.alignLeft}</button>
        <button type="button" class="dlite-bubble-btn" data-align="center" title="Rata Tengah">${Icons.alignCenter}</button>
        <button type="button" class="dlite-bubble-btn" data-align="right" title="Rata Kanan">${Icons.alignRight}</button>
      </div>
      <div class="dlite-bubble-sep"></div>
      <div class="dlite-bubble-group">
        <button type="button" class="dlite-bubble-btn" data-size="25%" title="Ukuran 25%">25%</button>
        <button type="button" class="dlite-bubble-btn" data-size="50%" title="Ukuran 50%">50%</button>
        <button type="button" class="dlite-bubble-btn" data-size="75%" title="Ukuran 75%">75%</button>
        <button type="button" class="dlite-bubble-btn" data-size="100%" title="Ukuran Penuh (100%)">100%</button>
      </div>
      <div class="dlite-bubble-sep"></div>
      <div class="dlite-bubble-group">
        <button type="button" class="dlite-bubble-btn" data-action="alt" title="Edit Teks Alternatif">${Icons.edit}</button>
        <button type="button" class="dlite-bubble-btn dlite-bubble-danger" data-action="delete" title="Hapus Gambar">${Icons.trash}</button>
      </div>
    `;

    document.body.appendChild(this.bubble);

    // Bubble button events
    this.bubble.addEventListener('click', async (e) => {
      const btn = e.target.closest('.dlite-bubble-btn');
      if (!btn || !this.selectedImage) return;

      const align = btn.dataset.align;
      const size = btn.dataset.size;
      const action = btn.dataset.action;

      const figure = this.selectedImage.closest('figure') || this.selectedImage;

      if (align) {
        figure.classList.remove('dlite-align-left', 'dlite-align-center', 'dlite-align-right');
        figure.classList.add(`dlite-align-${align}`);
        this.positionBubble();
        this.editor._onContentChanged();
      } else if (size) {
        this.selectedImage.style.width = size;
        this.selectedImage.style.height = 'auto';
        this.positionBubble();
        this.editor._onContentChanged();
      } else if (action === 'alt') {
        const currentAlt = this.selectedImage.getAttribute('alt') || '';
        const newAlt = await modal.prompt({
          title: 'Ubah Teks Alternatif (Alt Text)',
          message: 'Teks ini membantu pembaca tuna netra dan SEO gambar:',
          defaultValue: currentAlt,
          placeholder: 'Deskripsi gambar...'
        });
        if (newAlt !== null) {
          this.selectedImage.setAttribute('alt', newAlt);
          toast.success('Alt text gambar berhasil diperbarui.');
          this.editor._onContentChanged();
        }
      } else if (action === 'delete') {
        const confirmed = await modal.confirm({
          title: 'Hapus Gambar',
          message: 'Apakah Anda yakin ingin menghapus gambar ini?',
          confirmText: 'Hapus',
          isDestructive: true
        });
        if (confirmed) {
          figure.remove();
          this.hideBubble();
          this.editor._onContentChanged();
          this.editor.history.record(true);
          toast.info('Gambar telah dihapus.');
        }
      }
    });
  }

  _initClickWatcher() {
    this._onClick = (e) => {
      if (e.target.tagName === 'IMG' && this.editor.canvas.contains(e.target)) {
        this.selectImage(e.target);
      } else {
        this.hideBubble();
      }
    };
    this.editor.canvas.addEventListener('click', this._onClick);

    this._onResize = () => {
      if (this.selectedImage) this.positionBubble();
    };
    window.addEventListener('resize', this._onResize);

    this._onScroll = () => {
      if (this.selectedImage) this.positionBubble();
    };
    document.addEventListener('scroll', this._onScroll, true);
  }

  selectImage(img) {
    if (this.selectedImage) {
      this.selectedImage.classList.remove('dlite-selected-img');
    }
    this.selectedImage = img;
    img.classList.add('dlite-selected-img');
    this.showBubble();
  }

  showBubble() {
    this.bubble.classList.remove('dlite-bubble-hidden');
    this.positionBubble();
  }

  hideBubble() {
    if (this.selectedImage) {
      this.selectedImage.classList.remove('dlite-selected-img');
      this.selectedImage = null;
    }
    this.bubble.classList.add('dlite-bubble-hidden');
  }

  positionBubble() {
    if (!this.selectedImage) return;
    const rect = this.selectedImage.getBoundingClientRect();
    const bubbleRect = this.bubble.getBoundingClientRect();

    let top = rect.top - bubbleRect.height - 10;
    let left = rect.left + (rect.width / 2) - (bubbleRect.width / 2);

    if (top < 10) top = rect.bottom + 10;
    if (left < 10) left = 10;
    if (left + bubbleRect.width > window.innerWidth) {
      left = window.innerWidth - bubbleRect.width - 10;
    }

    this.bubble.style.top = `${top}px`;
    this.bubble.style.left = `${left}px`;
  }

  destroy() {
    this.editor.canvas.removeEventListener('click', this._onClick);
    window.removeEventListener('resize', this._onResize);
    document.removeEventListener('scroll', this._onScroll, true);
    if (this.bubble?.parentNode) {
      this.bubble.parentNode.removeChild(this.bubble);
    }
  }
}

// --- Module: src/plugins/FilePlugin.js ---
/**
 * File Plugin for D-Lite Editor
 * Uploads & renders interactive download cards for documents and files
 */
class FilePlugin {
  constructor(editor) {
    this.editor = editor;
  }

  /**
   * Open the File Attachment Modal
   */
  openModal() {
    this.editor.selection.save();

    const content = document.createElement('div');
    content.className = 'dlite-file-modal-content';
    content.innerHTML = `
      <div class="dlite-drop-area" id="dlite-file-drop">
        <div class="dlite-drop-icon">${Icons.file}</div>
        <p class="dlite-drop-text">Pilih atau seret berkas dokumen ke sini</p>
        <small class="dlite-drop-sub">PDF, DOCX, XLSX, PPTX, ZIP, TXT (Maks. 25MB)</small>
        <input type="file" id="dlite-doc-input" class="dlite-hidden-input" />
        <button class="dlite-btn dlite-btn-primary dlite-btn-sm" type="button" id="dlite-browse-doc-btn">Pilih Berkas</button>
      </div>
    `;

    const fileInput = content.querySelector('#dlite-doc-input');
    const browseBtn = content.querySelector('#dlite-browse-doc-btn');
    const dropArea = content.querySelector('#dlite-file-drop');

    browseBtn.addEventListener('click', () => fileInput.click());
    dropArea.addEventListener('click', (e) => {
      if (e.target !== browseBtn) fileInput.click();
    });

    const modalInstance = modal.open({
      title: 'Sisipkan Lampiran Berkas',
      content,
      width: '460px',
      buttons: [
        {
          text: 'Batal',
          type: 'secondary'
        }
      ]
    });

    fileInput.addEventListener('change', () => {
      if (fileInput.files && fileInput.files[0]) {
        modalInstance.close();
        this.editor.plugins.uploader.upload(fileInput.files[0]);
      }
    });
  }

  /**
   * Helper to format file sizes
   */
  formatSize(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  /**
   * Create a smart file attachment card widget
   */
  createFileCard({ url, name, size }) {
    const container = document.createElement('div');
    container.className = 'dlite-file-container dlite-align-left';
    container.contentEditable = 'false';

    const card = document.createElement('div');
    card.className = 'dlite-file-card';
    card.setAttribute('data-file-url', url);
    card.setAttribute('data-file-name', name);
    card.setAttribute('data-file-size', size);

    const ext = name.split('.').pop().toUpperCase();
    const formattedSize = typeof size === 'number' ? this.formatSize(size) : size;

    const safeName = Sanitizer.escapeHtml(name);
    const safeExt = Sanitizer.escapeHtml(ext);
    const safeSize = Sanitizer.escapeHtml(formattedSize);
    const safeUrl = Sanitizer.escapeHtml(url);

    card.innerHTML = `
      <div class="dlite-file-card-icon">
        <span class="dlite-file-badge">${safeExt}</span>
      </div>
      <div class="dlite-file-card-details">
        <div class="dlite-file-card-name" title="${safeName}">${safeName}</div>
        <div class="dlite-file-card-meta">${safeSize} • Dokumen</div>
      </div>
      <div class="dlite-file-card-actions">
        <button type="button" class="dlite-file-card-btn dlite-align-file-btn" data-align="left" title="Rata Kiri">${Icons.alignLeft}</button>
        <button type="button" class="dlite-file-card-btn dlite-align-file-btn" data-align="center" title="Rata Tengah">${Icons.alignCenter}</button>
        <button type="button" class="dlite-file-card-btn dlite-align-file-btn" data-align="right" title="Rata Kanan">${Icons.alignRight}</button>
        <a href="${safeUrl}" target="_blank" download="${safeName}" class="dlite-file-card-btn" title="Unduh Berkas">${Icons.download}</a>
        <button type="button" class="dlite-file-card-btn dlite-btn-danger-hover dlite-del-file-btn" title="Hapus Berkas">${Icons.trash}</button>
      </div>
    `;

    // Alignment buttons
    card.querySelectorAll('.dlite-align-file-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const align = btn.dataset.align;
        container.classList.remove('dlite-align-left', 'dlite-align-center', 'dlite-align-right');
        container.classList.add(`dlite-align-${align}`);
        this.editor._onContentChanged();
        this.editor.history.record(true);
      });
    });

    // Handle delete button
    card.querySelector('.dlite-del-file-btn').addEventListener('click', async (e) => {
      e.stopPropagation();
      const confirmed = await modal.confirm({
        title: 'Hapus Berkas',
        message: `Apakah Anda yakin ingin menghapus lampiran "${name}"?`,
        confirmText: 'Hapus',
        isDestructive: true
      });
      if (confirmed) {
        container.remove();
        this.editor._onContentChanged();
        this.editor.history.record(true);
        toast.info('Lampiran berkas telah dihapus.');
      }
    });

    container.appendChild(card);
    return container;
  }
}

// --- Module: src/plugins/LinkPlugin.js ---
/**
 * Link Plugin for D-Lite Editor
 * Custom modal insertion and floating link preview/edit bubble
 */
class LinkPlugin {
  constructor(editor) {
    this.editor = editor;
    this.activeLink = null;
    this.popover = null;
    this.init();
  }

  init() {
    this._createPopover();
    this._initClickWatcher();
  }

  /**
   * Open Custom Modal to insert or edit a link
   */
  openModal(linkElement = null) {
    this.editor.selection.save();

    const range = this.editor.selection.getRange();
    const selectedText = range ? range.toString().trim() : '';

    const currentUrl = linkElement ? linkElement.getAttribute('href') : '';
    const currentText = linkElement ? linkElement.textContent : selectedText;
    const currentTargetBlank = linkElement ? linkElement.getAttribute('target') === '_blank' : true;

    const safeText = Sanitizer.escapeHtml(currentText);
    const safeUrl = Sanitizer.escapeHtml(currentUrl);

    const content = document.createElement('div');
    content.className = 'dlite-link-modal-content';
    content.innerHTML = `
      <div class="dlite-form-group">
        <label class="dlite-label">Teks Tampilan</label>
        <input type="text" id="dlite-link-text" class="dlite-input" value="${safeText}" placeholder="Contoh: Kunjungi Web Kami" />
      </div>
      <div class="dlite-form-group">
        <label class="dlite-label">Alamat URL Tautan</label>
        <input type="url" id="dlite-link-url" class="dlite-input" value="${safeUrl}" placeholder="https://example.com" />
      </div>
      <div class="dlite-form-checkbox">
        <label class="dlite-checkbox-label">
          <input type="checkbox" id="dlite-link-target" ${currentTargetBlank ? 'checked' : ''} />
          Buka di tab baru (target="_blank")
        </label>
      </div>
    `;

    modal.open({
      title: linkElement ? 'Ubah Tautan' : 'Sisipkan Tautan',
      content,
      width: '450px',
      buttons: [
        {
          text: 'Batal',
          type: 'secondary'
        },
        {
          text: linkElement ? 'Simpan Perubahan' : 'Sisipkan Tautan',
          type: 'primary',
          onClick: () => {
            const urlInput = content.querySelector('#dlite-link-url').value.trim();
            const textInput = content.querySelector('#dlite-link-text').value.trim();
            const targetBlank = content.querySelector('#dlite-link-target').checked;

            if (!urlInput) {
              toast.warning('Silakan masukkan alamat URL.');
              return false;
            }

            const dangerousProtocols = /^(javascript|vbscript|data|file):/i;
            if (dangerousProtocols.test(urlInput.replace(/\s+/g, ''))) {
              toast.error('Protokol URL tidak diizinkan demi keamanan.');
              return false;
            }

            let validUrl = urlInput;
            if (!validUrl.match(/^https?:\/\//i) && !validUrl.startsWith('/') && !validUrl.startsWith('#') && !validUrl.startsWith('mailto:')) {
              validUrl = 'https://' + validUrl;
            }

            if (linkElement) {
              linkElement.setAttribute('href', validUrl);
              linkElement.textContent = textInput || validUrl;
              if (targetBlank) {
                linkElement.setAttribute('target', '_blank');
                linkElement.setAttribute('rel', 'noopener noreferrer');
              } else {
                linkElement.removeAttribute('target');
                linkElement.removeAttribute('rel');
              }
              toast.success('Tautan berhasil diperbarui.');
            } else {
              this.editor.selection.restore();
              const a = document.createElement('a');
              a.href = validUrl;
              a.textContent = textInput || validUrl;
              if (targetBlank) {
                a.target = '_blank';
                a.rel = 'noopener noreferrer';
              }
              this.editor.selection.insertNode(a);
              toast.success('Tautan berhasil disisipkan.');
            }

            this.editor._onContentChanged();
            this.editor.history.record(true);
            return true;
          }
        }
      ]
    });
  }

  /**
   * Remove link from current selection or active link
   */
  unlink() {
    this.editor.selection.restore();
    const link = this.activeLink || this.editor.selection.getClosest('a');
    if (link) {
      const parent = link.parentNode;
      while (link.firstChild) {
        parent.insertBefore(link.firstChild, link);
      }
      parent.removeChild(link);
      this.hidePopover();
      this.editor._onContentChanged();
      this.editor.history.record(true);
      toast.info('Tautan dilepas.');
    } else {
      document.execCommand('unlink');
      this.editor._onContentChanged();
      this.editor.history.record(true);
      toast.info('Tautan dilepas.');
    }
  }

  _createPopover() {
    this.popover = document.createElement('div');
    this.popover.className = 'dlite-link-popover dlite-bubble-hidden';
    this.popover.innerHTML = `
      <a href="#" target="_blank" class="dlite-link-preview-url" rel="noopener noreferrer">
        <span class="dlite-link-preview-text"></span>
        ${Icons.externalLink}
      </a>
      <div class="dlite-bubble-sep"></div>
      <button type="button" class="dlite-bubble-btn" data-action="edit" title="Ubah Tautan">${Icons.edit}</button>
      <button type="button" class="dlite-bubble-btn dlite-bubble-danger" data-action="unlink" title="Hapus Tautan">${Icons.unlink}</button>
    `;

    document.body.appendChild(this.popover);

    this.popover.addEventListener('click', (e) => {
      const btn = e.target.closest('.dlite-bubble-btn');
      if (!btn || !this.activeLink) return;

      const action = btn.dataset.action;
      if (action === 'edit') {
        const link = this.activeLink;
        this.hidePopover();
        this.openModal(link);
      } else if (action === 'unlink') {
        const parent = this.activeLink.parentNode;
        while (this.activeLink.firstChild) {
          parent.insertBefore(this.activeLink.firstChild, this.activeLink);
        }
        parent.removeChild(this.activeLink);
        this.hidePopover();
        this.editor._onContentChanged();
        this.editor.history.record(true);
        toast.info('Tautan dilepas.');
      }
    });
  }

  _initClickWatcher() {
    this._onClick = (e) => {
      const link = e.target.closest('a');
      if (link && this.editor.canvas.contains(link)) {
        e.preventDefault();
        this.showPopover(link);
      } else {
        this.hidePopover();
      }
    };
    this.editor.canvas.addEventListener('click', this._onClick);

    this._onResize = () => {
      if (this.activeLink) this.positionPopover();
    };
    window.addEventListener('resize', this._onResize);

    this._onScroll = () => {
      if (this.activeLink) this.positionPopover();
    };
    document.addEventListener('scroll', this._onScroll, true);
  }

  showPopover(link) {
    this.activeLink = link;
    const url = (link.getAttribute('href') || '#').trim();
    const previewLink = this.popover.querySelector('.dlite-link-preview-url');
    const previewText = this.popover.querySelector('.dlite-link-preview-text');

    const isSafe = /^(https?:\/\/|\/|#|mailto:|tel:)/i.test(url);
    if (isSafe) {
      previewLink.href = url;
      previewLink.target = '_blank';
      previewLink.rel = 'noopener noreferrer';
    } else {
      previewLink.href = 'javascript:void(0)';
      previewLink.removeAttribute('target');
      previewLink.removeAttribute('rel');
    }
    previewText.textContent = url;

    this.popover.classList.remove('dlite-bubble-hidden');
    this.positionPopover();
  }

  hidePopover() {
    this.activeLink = null;
    this.popover.classList.add('dlite-bubble-hidden');
  }

  positionPopover() {
    if (!this.activeLink) return;
    const rect = this.activeLink.getBoundingClientRect();
    const popRect = this.popover.getBoundingClientRect();

    let top = rect.bottom + 8;
    let left = rect.left + (rect.width / 2) - (popRect.width / 2);

    if (left < 10) left = 10;
    if (left + popRect.width > window.innerWidth) {
      left = window.innerWidth - popRect.width - 10;
    }

    this.popover.style.top = `${top}px`;
    this.popover.style.left = `${left}px`;
  }

  destroy() {
    this.editor.canvas.removeEventListener('click', this._onClick);
    window.removeEventListener('resize', this._onResize);
    document.removeEventListener('scroll', this._onScroll, true);
    if (this.popover?.parentNode) {
      this.popover.parentNode.removeChild(this.popover);
    }
  }
}

// --- Module: src/plugins/TablePlugin.js ---
/**
 * Table Plugin for D-Lite Editor
 * Interactive grid picker, row/col operations, and table bubble toolbar
 */
class TablePlugin {
  constructor(editor) {
    this.editor = editor;
    this.activeCell = null;
    this.activeTable = null;
    this.bubble = null;
    this.init();
  }

  init() {
    this._createTableBubble();
    this._initClickWatcher();
  }

  /**
   * Create interactive grid picker dropdown content
   */
  createGridPicker(onSelect) {
    const container = document.createElement('div');
    container.className = 'dlite-table-grid-picker';

    const info = document.createElement('div');
    info.className = 'dlite-table-grid-info';
    info.textContent = '1 x 1';

    const grid = document.createElement('div');
    grid.className = 'dlite-table-grid-cells';

    const maxRows = 6;
    const maxCols = 8;
    const cells = [];

    for (let r = 1; r <= maxRows; r++) {
      for (let c = 1; c <= maxCols; c++) {
        const cell = document.createElement('div');
        cell.className = 'dlite-grid-cell';
        cell.dataset.row = r;
        cell.dataset.col = c;

        cell.addEventListener('mouseenter', () => {
          info.textContent = `${c} x ${r} Tabel`;
          cells.forEach(item => {
            const ir = parseInt(item.dataset.row, 10);
            const ic = parseInt(item.dataset.col, 10);
            if (ir <= r && ic <= c) {
              item.classList.add('highlight');
            } else {
              item.classList.remove('highlight');
            }
          });
        });

        cell.addEventListener('click', (e) => {
          e.stopPropagation();
          onSelect(r, c);
        });

        grid.appendChild(cell);
        cells.push(cell);
      }
    }

    container.appendChild(grid);
    container.appendChild(info);
    return container;
  }

  /**
   * Insert a new table with given rows and columns
   */
  insertTable(rows, cols) {
    const table = document.createElement('table');
    table.className = 'dlite-table';

    // Thead
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    for (let c = 0; c < cols; c++) {
      const th = document.createElement('th');
      th.innerHTML = `Header ${c + 1}`;
      headerRow.appendChild(th);
    }
    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Tbody
    const tbody = document.createElement('tbody');
    for (let r = 0; r < rows; r++) {
      const tr = document.createElement('tr');
      for (let c = 0; c < cols; c++) {
        const td = document.createElement('td');
        td.innerHTML = '<br>';
        tr.appendChild(td);
      }
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);

    // Wrap with responsive container
    const wrapper = document.createElement('div');
    wrapper.className = 'dlite-table-responsive';
    wrapper.appendChild(table);

    // Add trailing paragraph so user can continue writing below table
    const p = document.createElement('p');
    p.innerHTML = '<br>';

    this.editor.selection.insertBlockNode(wrapper);
    wrapper.after(p);

    // Focus cursor in first header cell
    const firstTh = table.querySelector('th');
    if (firstTh) {
      const range = document.createRange();
      range.selectNodeContents(firstTh);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      this.editor.selection.save();
    }

    this.editor._onContentChanged();
    this.editor.history.record(true);
    toast.success(`Tabel (${cols}x${rows}) berhasil disisipkan.`);
  }

  _createTableBubble() {
    this.bubble = document.createElement('div');
    this.bubble.className = 'dlite-table-bubble dlite-bubble-hidden';
    this.bubble.innerHTML = `
      <button type="button" class="dlite-bubble-btn" data-action="row-above" title="Tambah Baris di Atas">+ Baris Atas</button>
      <button type="button" class="dlite-bubble-btn" data-action="row-below" title="Tambah Baris di Bawah">+ Baris Bawah</button>
      <button type="button" class="dlite-bubble-btn dlite-bubble-danger" data-action="del-row" title="Hapus Baris Ini">Hapus Baris</button>
      <div class="dlite-bubble-sep"></div>
      <button type="button" class="dlite-bubble-btn" data-action="col-left" title="Tambah Kolom di Kiri">+ Kolom Kiri</button>
      <button type="button" class="dlite-bubble-btn" data-action="col-right" title="Tambah Kolom di Kanan">+ Kolom Kanan</button>
      <button type="button" class="dlite-bubble-btn dlite-bubble-danger" data-action="del-col" title="Hapus Kolom Ini">Hapus Kolom</button>
      <div class="dlite-bubble-sep"></div>
      <button type="button" class="dlite-bubble-btn dlite-bubble-danger" data-action="del-table" title="Hapus Seluruh Tabel">${Icons.trash}</button>
    `;

    document.body.appendChild(this.bubble);

    this.bubble.addEventListener('click', async (e) => {
      const btn = e.target.closest('.dlite-bubble-btn');
      if (!btn || !this.activeCell || !this.activeTable) return;

      const action = btn.dataset.action;
      const row = this.activeCell.closest('tr');
      const cellIndex = this.activeCell.cellIndex;

      switch (action) {
        case 'row-above': {
          const isHeader = row.parentNode.tagName === 'THEAD';
          const newRow = this._cloneRow(row, isHeader);
          row.parentNode.insertBefore(newRow, row);
          break;
        }
        case 'row-below': {
          if (row.parentNode.tagName === 'THEAD') {
            let tbody = this.activeTable.querySelector('tbody');
            if (!tbody) {
              tbody = document.createElement('tbody');
              this.activeTable.appendChild(tbody);
            }
            const newRow = this._cloneRow(row, false);
            tbody.insertBefore(newRow, tbody.firstChild);
          } else {
            const newRow = this._cloneRow(row, false);
            row.parentNode.insertBefore(newRow, row.nextSibling);
          }
          break;
        }
        case 'del-row': {
          if (this.activeTable.querySelectorAll('tr').length <= 1) {
            toast.warning('Tabel harus memiliki minimal 1 baris.');
            return;
          }
          row.remove();
          this.hideBubble();
          break;
        }
        case 'col-left': {
          Array.from(this.activeTable.querySelectorAll('tr')).forEach(tr => {
            const isHeader = tr.parentNode.tagName === 'THEAD';
            const cell = isHeader ? document.createElement('th') : document.createElement('td');
            cell.innerHTML = '<br>';
            tr.insertBefore(cell, tr.children[cellIndex]);
          });
          break;
        }
        case 'col-right': {
          Array.from(this.activeTable.querySelectorAll('tr')).forEach(tr => {
            const isHeader = tr.parentNode.tagName === 'THEAD';
            const cell = isHeader ? document.createElement('th') : document.createElement('td');
            cell.innerHTML = '<br>';
            tr.insertBefore(cell, tr.children[cellIndex]?.nextSibling);
          });
          break;
        }
        case 'del-col': {
          if (row.children.length <= 1) {
            toast.warning('Tabel harus memiliki minimal 1 kolom.');
            return;
          }
          Array.from(this.activeTable.querySelectorAll('tr')).forEach(tr => {
            if (tr.children[cellIndex]) tr.children[cellIndex].remove();
          });
          this.hideBubble();
          break;
        }
        case 'del-table': {
          const confirmed = await modal.confirm({
            title: 'Hapus Tabel',
            message: 'Apakah Anda yakin ingin menghapus seluruh tabel ini beserta isinya?',
            confirmText: 'Hapus Tabel',
            isDestructive: true
          });
          if (confirmed) {
            const wrapper = this.activeTable.closest('.dlite-table-responsive') || this.activeTable;
            wrapper.remove();
            this.hideBubble();
            toast.info('Tabel telah dihapus.');
          }
          break;
        }
      }

      this.editor._onContentChanged();
      this.editor.history.record(true);
      if (this.activeCell) this.positionBubble();
    });
  }

  _cloneRow(row, isHeader = false) {
    const newRow = document.createElement('tr');
    Array.from(row.children).forEach(() => {
      const cell = isHeader ? document.createElement('th') : document.createElement('td');
      cell.innerHTML = '<br>';
      newRow.appendChild(cell);
    });
    return newRow;
  }

  _initClickWatcher() {
    this._onClick = (e) => {
      const cell = e.target.closest('td, th');
      if (cell && this.editor.canvas.contains(cell)) {
        this.activeCell = cell;
        this.activeTable = cell.closest('table');
        this.showBubble();
      } else {
        this.hideBubble();
      }
    };
    this.editor.canvas.addEventListener('click', this._onClick);

    this._onResize = () => {
      if (this.activeCell) this.positionBubble();
    };
    window.addEventListener('resize', this._onResize);

    this._onScroll = () => {
      if (this.activeCell) this.positionBubble();
    };
    document.addEventListener('scroll', this._onScroll, true);
  }

  showBubble() {
    this.bubble.classList.remove('dlite-bubble-hidden');
    this.positionBubble();
  }

  hideBubble() {
    this.activeCell = null;
    this.activeTable = null;
    this.bubble.classList.add('dlite-bubble-hidden');
  }

  positionBubble() {
    if (!this.activeCell || !this.activeTable) return;
    const tableRect = this.activeTable.getBoundingClientRect();
    const bubbleRect = this.bubble.getBoundingClientRect();

    let top = tableRect.top - bubbleRect.height - 8;
    let left = tableRect.left + (tableRect.width / 2) - (bubbleRect.width / 2);

    if (top < 10) top = tableRect.bottom + 8;
    if (left < 10) left = 10;
    if (left + bubbleRect.width > window.innerWidth) {
      left = window.innerWidth - bubbleRect.width - 10;
    }

    this.bubble.style.top = `${top}px`;
    this.bubble.style.left = `${left}px`;
  }

  destroy() {
    this.editor.canvas.removeEventListener('click', this._onClick);
    window.removeEventListener('resize', this._onResize);
    document.removeEventListener('scroll', this._onScroll, true);
    if (this.bubble?.parentNode) {
      this.bubble.parentNode.removeChild(this.bubble);
    }
  }
}

// --- Module: src/plugins/CodePlugin.js ---
/**
 * Code Plugin for D-Lite Editor
 * Code blocks, blockquotes, and HTML Source View Toggle Mode
 */
class CodePlugin {
  constructor(editor) {
    this.editor = editor;
    this.isSourceMode = false;
    this.sourceTextarea = null;
    this.init();
  }

  init() {
    this.sourceTextarea = document.createElement('textarea');
    this.sourceTextarea.className = 'dlite-source-textarea dlite-hidden';
    this.sourceTextarea.spellcheck = false;
    this.editor.container.querySelector('.dlite-body-wrapper').appendChild(this.sourceTextarea);

    this.sourceTextarea.addEventListener('input', () => {
      this.editor._onContentChanged();
    });
  }

  /**
   * Insert a formatted code block <pre><code>...</code></pre>
   */
  insertCodeBlock() {
    this.editor.selection.restore();
    const pre = document.createElement('pre');
    pre.className = 'dlite-code-block';
    const code = document.createElement('code');
    code.textContent = '// Tuliskan potongan kode di sini...';
    pre.appendChild(code);

    const p = document.createElement('p');
    p.innerHTML = '<br>';

    this.editor.selection.insertNode(pre);
    pre.after(p);

    this.editor._onContentChanged();
    this.editor.history.record(true);
  }

  /**
   * Insert a modern blockquote
   */
  insertBlockquote() {
    this.editor.plugins.formatting.blockquote();
  }

  /**
   * Toggle between visual WYSIWYG mode and raw HTML Source Code mode
   */
  toggleSourceMode() {
    this.isSourceMode = !this.isSourceMode;

    if (this.isSourceMode) {
      // Switch to HTML source
      const currentHTML = this.editor.getHTML();
      const formatted = Sanitizer.formatHTML(currentHTML);
      this.sourceTextarea.value = formatted;

      this.editor.canvas.classList.add('dlite-hidden');
      this.sourceTextarea.classList.remove('dlite-hidden');
      this.editor.container.classList.add('dlite-source-active');

      toast.info('Mode Kode Sumber (HTML) aktif.');
    } else {
      // Switch back to Visual
      const html = this.sourceTextarea.value;
      const cleanHtml = Sanitizer.clean(html);
      this.editor.canvas.innerHTML = cleanHtml;

      this.sourceTextarea.classList.add('dlite-hidden');
      this.editor.canvas.classList.remove('dlite-hidden');
      this.editor.container.classList.remove('dlite-source-active');

      this.editor._onContentChanged();
      this.editor.history.record(true);
      toast.info('Mode Visual WYSIWYG aktif.');
    }

    this.editor.toolbar?.updateSourceButton(this.isSourceMode);
  }
}

// --- Module: src/plugins/MediaEmbedPlugin.js ---
/**
 * MediaEmbedPlugin for D-Lite Editor
 * Embeds responsive YouTube, Vimeo, and validated media iframes
 */
class MediaEmbedPlugin {
  constructor(editor) {
    this.editor = editor;
  }

  openModal() {
    this.editor.selection.save();

    const content = document.createElement('div');
    content.className = 'dlite-media-embed-content';
    content.innerHTML = `
      <div class="dlite-form-group">
        <label class="dlite-label">Tautan Video (YouTube / Vimeo)</label>
        <input type="text" id="dlite-video-url" class="dlite-input" placeholder="https://www.youtube.com/watch?v=... atau https://vimeo.com/..." />
        <small class="dlite-drop-sub">Mendukung tautan video YouTube atau Vimeo yang aman</small>
      </div>
      <div class="dlite-form-group">
        <label class="dlite-label">Rasio Aspek</label>
        <select id="dlite-video-ratio" class="dlite-input">
          <option value="16-9" selected>16:9 (Layar Lebar Standar)</option>
          <option value="4-3">4:3 (Klasik)</option>
          <option value="1-1">1:1 (Persegi)</option>
        </select>
      </div>
    `;

    modal.open({
      title: 'Sisipkan Video / Media Embed',
      content,
      width: '460px',
      buttons: [
        { text: 'Batal', type: 'secondary' },
        {
          text: 'Sisipkan Video',
          type: 'primary',
          onClick: () => {
            const input = content.querySelector('#dlite-video-url').value.trim();
            const ratio = content.querySelector('#dlite-video-ratio').value;
            if (!input) {
              toast.warning('Silakan masukkan URL video.');
              return false;
            }

            return this.insertVideo(input, ratio);
          }
        }
      ]
    });
  }

  insertVideo(input, ratio = '16-9') {
    // Security check: reject javascript:, data:, vbscript:, file:
    const dangerous = /^(javascript|vbscript|data|file):/i;
    if (dangerous.test(input.replace(/\s+/g, ''))) {
      toast.error('URL mengandung protokol yang berbahaya dan ditolak.');
      return false;
    }

    let embedUrl = '';
    // Check if user pasted full <iframe>
    if (input.includes('<iframe') && input.includes('src=')) {
      const match = input.match(/src=["']([^"']+)["']/i);
      if (match) input = match[1];
    }

    // YouTube check
    const ytMatch = input.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/i);
    if (ytMatch) {
      embedUrl = `https://www.youtube.com/embed/${ytMatch[1]}`;
    } else {
      // Vimeo check
      const vimeoMatch = input.match(/vimeo\.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|)(\d+)(?:$|\/|\?)/i);
      if (vimeoMatch && vimeoMatch[3]) {
        embedUrl = `https://player.vimeo.com/video/${vimeoMatch[3]}`;
      }
    }

    if (!embedUrl) {
      toast.warning('Format tautan tidak didukung. Harap masukkan tautan video YouTube atau Vimeo yang valid.');
      return false;
    }

    const container = document.createElement('div');
    container.className = `dlite-video-responsive ratio-${ratio}`;
    container.contentEditable = 'false';

    const iframe = document.createElement('iframe');
    iframe.src = embedUrl;
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allowfullscreen', 'true');
    iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');
    iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-presentation');
    iframe.setAttribute('loading', 'lazy');

    container.appendChild(iframe);

    const p = document.createElement('p');
    p.innerHTML = '<br>';

    this.editor.selection.insertBlockNode(container);
    container.after(p);

    this.editor._onContentChanged();
    this.editor.history.record(true);
    toast.success('Video berhasil disisipkan.');
    return true;
  }
}

// --- Module: src/plugins/SpecialCharPlugin.js ---
/**
 * SpecialCharPlugin for D-Lite Editor
 * Emojis, math symbols, currency, and typography character picker
 */
class SpecialCharPlugin {
  constructor(editor) {
    this.editor = editor;
  }

  openModal() {
    this.editor.selection.save();

    const emojis = ['😀','😃','😄','😁','😆','😅','😂','🤣','😊','😇','🙂','🙃','😉','😌','😍','🥰','😘','😋','😛','😜','😎','🤩','🥳','😏','🤔','🤫','🤭','🤗','🤝','👍','👎','👏','🙌','🙏','💪','🔥','✨','🎉','🚀','💡','⭐','❤️','💯','✅','❌','⚠️','☕','🏆','💻','📱'];
    const symbols = ['©','®','™','€','$','£','¥','₽','₩','¢','§','¶','±','×','÷','≠','≈','≤','≥','∞','√','π','µ','Ω','∆','∑','∫','‰','°','℃','℉'];
    const arrows = ['←','→','↑','↓','↔','↕','↵','⇒','⇐','⇑','⇓','⇔','➔','«','»','—','–','•','…','‹','›','“','”','‘','’'];

    const content = document.createElement('div');
    content.className = 'dlite-special-char-modal';
    content.innerHTML = `
      <div class="dlite-tabs">
        <button class="dlite-tab-btn active" data-tab="emoji" type="button">Emoji</button>
        <button class="dlite-tab-btn" data-tab="symbols" type="button">Simbol & Mata Uang</button>
        <button class="dlite-tab-btn" data-tab="arrows" type="button">Panah & Tipografi</button>
      </div>

      <div class="dlite-tab-pane active" id="tab-emoji">
        <div class="dlite-char-grid" id="grid-emoji"></div>
      </div>
      <div class="dlite-tab-pane" id="tab-symbols">
        <div class="dlite-char-grid" id="grid-symbols"></div>
      </div>
      <div class="dlite-tab-pane" id="tab-arrows">
        <div class="dlite-char-grid" id="grid-arrows"></div>
      </div>
    `;

    // Tab switching
    const tabs = content.querySelectorAll('.dlite-tab-btn');
    const panes = content.querySelectorAll('.dlite-tab-pane');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        panes.forEach(p => p.classList.remove('active'));
        tab.classList.add('active');
        content.querySelector(`#tab-${tab.dataset.tab}`).classList.add('active');
      });
    });

    const modalInstance = modal.open({
      title: 'Karakter Khusus & Emoji',
      content,
      width: '500px',
      buttons: [
        { text: 'Selesai', type: 'primary' }
      ]
    });

    const renderGrid = (containerId, list) => {
      const container = content.querySelector(containerId);
      list.forEach(char => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'dlite-char-btn';
        btn.textContent = char;
        btn.title = char;
        btn.addEventListener('click', () => {
          this.editor.selection.restore();
          this.editor.selection.insertText(char);
          this.editor._onContentChanged();
          this.editor.history.record();
          toast.success(`Karakter "${char}" disisipkan.`);
          modalInstance.close();
        });
        container.appendChild(btn);
      });
    };

    renderGrid('#grid-emoji', emojis);
    renderGrid('#grid-symbols', symbols);
    renderGrid('#grid-arrows', arrows);
  }
}

// --- Module: src/plugins/FindReplacePlugin.js ---
/**
 * FindReplacePlugin for D-Lite Editor
 * Find & Replace with case-sensitivity and replace-all capabilities
 */
class FindReplacePlugin {
  constructor(editor) {
    this.editor = editor;
  }

  openModal() {
    const content = document.createElement('div');
    content.className = 'dlite-find-replace-modal';
    content.innerHTML = `
      <div class="dlite-form-group">
        <label class="dlite-label">Cari Teks</label>
        <input type="text" id="dlite-find-input" class="dlite-input" placeholder="Masukkan kata yang ingin dicari..." />
      </div>
      <div class="dlite-form-group">
        <label class="dlite-label">Ganti Dengan</label>
        <input type="text" id="dlite-replace-input" class="dlite-input" placeholder="Teks pengganti..." />
      </div>
      <div class="dlite-form-checkbox">
        <label class="dlite-checkbox-label">
          <input type="checkbox" id="dlite-match-case" />
          Cocokkan huruf besar/kecil (Match case)
        </label>
      </div>
    `;

    modal.open({
      title: 'Cari dan Ganti Teks',
      content,
      width: '460px',
      buttons: [
        { text: 'Tutup', type: 'secondary' },
        {
          text: 'Ganti Semua',
          type: 'primary',
          onClick: () => {
            const findTerm = content.querySelector('#dlite-find-input').value;
            const replaceTerm = content.querySelector('#dlite-replace-input').value;
            const matchCase = content.querySelector('#dlite-match-case').checked;

            if (!findTerm) {
              toast.warning('Silakan masukkan kata yang ingin dicari.');
              return false;
            }

            const count = this.replaceAll(findTerm, replaceTerm, matchCase);
            if (count > 0) {
              toast.success(`${count} kata "${findTerm}" berhasil diganti.`);
              return true;
            } else {
              toast.info(`Kata "${findTerm}" tidak ditemukan.`);
              return false;
            }
          }
        }
      ]
    });
  }

  replaceAll(findText, replaceText, matchCase = false) {
    const canvas = this.editor.canvas;
    const flags = matchCase ? 'g' : 'gi';
    const regex = new RegExp(this._escapeRegExp(findText), flags);

    let matchCount = 0;

    // Helper to replace only text inside text nodes (not inside tags or attributes)
    const walkTextNodes = (node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        const val = node.nodeValue;
        if (!val) return;
        const matches = val.match(regex);
        if (matches) {
          matchCount += matches.length;
          node.nodeValue = val.replace(regex, replaceText);
        }
      } else if (node.nodeType === Node.ELEMENT_NODE && node.nodeName !== 'SCRIPT' && node.nodeName !== 'STYLE') {
        node.childNodes.forEach(child => walkTextNodes(child));
      }
    };

    walkTextNodes(canvas);

    if (matchCount > 0) {
      this.editor._onContentChanged();
      this.editor.history.record(true);
    }

    return matchCount;
  }

  _escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
}

// --- Module: src/ui/StatusBar.js ---
/**
 * StatusBar Component for D-Lite Editor
 * Displays word count, character count, reading time estimation, and theme toggling
 * Highly optimized with textContent and debouncing to eliminate reflow lag
 */
class StatusBar {
  constructor(editor) {
    this.editor = editor;
    this.el = null;
    this.wordsEl = null;
    this.charsEl = null;
    this.readTimeEl = null;
    this._debounceTimer = null;
    this.init();
  }

  init() {
    this.el = document.createElement('div');
    this.el.className = 'dlite-statusbar';
    this.el.innerHTML = `
      <div class="dlite-statusbar-left">
        <span class="dlite-status-item dlite-status-words">0 kata</span>
        <span class="dlite-status-dot">•</span>
        <span class="dlite-status-item dlite-status-chars">0 karakter</span>
        <span class="dlite-status-dot">•</span>
        <span class="dlite-status-item dlite-status-readtime">&lt; 1 mnt baca</span>
      </div>
      <div class="dlite-statusbar-right">
        <button type="button" class="dlite-theme-toggle" title="Ganti Tema Gelap / Terang">
          ${Icons.themeMoon}
        </button>
        <span class="dlite-brand-label">D-Lite Editor</span>
      </div>
    `;

    this.wordsEl = this.el.querySelector('.dlite-status-words');
    this.charsEl = this.el.querySelector('.dlite-status-chars');
    this.readTimeEl = this.el.querySelector('.dlite-status-readtime');

    // Theme toggle button
    const themeBtn = this.el.querySelector('.dlite-theme-toggle');
    themeBtn.addEventListener('click', () => {
      this.editor.toggleTheme();
      const isDark = this.editor.container.classList.contains('dlite-theme-dark');
      themeBtn.innerHTML = isDark ? Icons.themeSun : Icons.themeMoon;
    });

    this.editor.container.appendChild(this.el);
    this.update(true);
  }

  update(immediate = false) {
    if (immediate) {
      this._calculate();
    } else {
      clearTimeout(this._debounceTimer);
      this._debounceTimer = setTimeout(() => this._calculate(), 150);
    }
  }

  _calculate() {
    // textContent is 10-50x faster than innerText as it avoids browser reflow
    const text = this.editor.canvas ? this.editor.canvas.textContent || '' : '';
    const cleanText = text.trim();

    // Characters
    const chars = cleanText.length;
    if (this.charsEl) this.charsEl.textContent = `${chars.toLocaleString()} karakter`;

    // Words
    const words = cleanText ? cleanText.split(/\s+/).filter(Boolean).length : 0;
    if (this.wordsEl) this.wordsEl.textContent = `${words.toLocaleString()} kata`;

    // Reading time (average 200 words per minute)
    const minutes = Math.ceil(words / 200);
    if (this.readTimeEl) this.readTimeEl.textContent = words < 10 ? '< 1 mnt baca' : `${minutes} mnt baca`;
  }

  destroy() {
    clearTimeout(this._debounceTimer);
    if (this.el?.parentNode) {
      this.el.parentNode.removeChild(this.el);
    }
  }
}

// --- Module: src/ui/BubbleMenu.js ---
/**
 * BubbleMenu - Floating inline formatting toolbar when selecting text
 */
class BubbleMenu {
  constructor(editor) {
    this.editor = editor;
    this.el = null;
    this.init();
  }

  init() {
    this.el = document.createElement('div');
    this.el.className = 'dlite-bubble-menu dlite-bubble-hidden';
    this.el.innerHTML = `
      <button type="button" class="dlite-bubble-btn" data-cmd="bold" title="Tebal (Ctrl+B)">${Icons.bold}</button>
      <button type="button" class="dlite-bubble-btn" data-cmd="italic" title="Miring (Ctrl+I)">${Icons.italic}</button>
      <button type="button" class="dlite-bubble-btn" data-cmd="underline" title="Garis Bawah (Ctrl+U)">${Icons.underline}</button>
      <button type="button" class="dlite-bubble-btn" data-cmd="strike" title="Coret">${Icons.strikethrough}</button>
      <div class="dlite-bubble-sep"></div>
      <button type="button" class="dlite-bubble-btn" data-cmd="h2" title="Heading 2">H2</button>
      <button type="button" class="dlite-bubble-btn" data-cmd="h3" title="Heading 3">H3</button>
      <button type="button" class="dlite-bubble-btn" data-cmd="quote" title="Kutipan">${Icons.quote}</button>
      <button type="button" class="dlite-bubble-btn" data-cmd="code" title="Inline Code">${Icons.code}</button>
      <div class="dlite-bubble-sep"></div>
      <button type="button" class="dlite-bubble-btn" data-cmd="link" title="Tautan">${Icons.link}</button>
    `;

    document.body.appendChild(this.el);

    this.el.addEventListener('click', (e) => {
      const btn = e.target.closest('.dlite-bubble-btn');
      if (!btn) return;

      const cmd = btn.dataset.cmd;
      switch (cmd) {
        case 'bold': this.editor.plugins.formatting.bold(); break;
        case 'italic': this.editor.plugins.formatting.italic(); break;
        case 'underline': this.editor.plugins.formatting.underline(); break;
        case 'strike': this.editor.plugins.formatting.strike(); break;
        case 'h2': this.editor.plugins.formatting.formatBlock('h2'); break;
        case 'h3': this.editor.plugins.formatting.formatBlock('h3'); break;
        case 'quote': this.editor.plugins.code.insertBlockquote(); break;
        case 'code': this.editor.plugins.formatting.inlineCode(); break;
        case 'link': this.editor.plugins.link.openModal(); break;
      }
      this.updatePosition();
    });

    this._onSelectionChange = () => {
      if (document.activeElement === this.editor.canvas) {
        this.updatePosition();
      }
    };
    document.addEventListener('selectionchange', this._onSelectionChange);

    this._onScroll = () => {
      if (!this.el.classList.contains('dlite-bubble-hidden')) {
        this.updatePosition();
      }
    };
    window.addEventListener('scroll', this._onScroll, { passive: true });

    this.editor.canvas.addEventListener('blur', () => {
      // Delay so clicks on bubble don't immediately hide it
      setTimeout(() => {
        if (!this.el.contains(document.activeElement)) {
          this.hide();
        }
      }, 200);
    });
  }

  updatePosition() {
    if (!this.editor.selection.hasSelection()) {
      this.hide();
      return;
    }

    const range = this.editor.selection.getRange();
    if (!range) {
      this.hide();
      return;
    }

    const rect = range.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
      this.hide();
      return;
    }

    this.show();
    const bubbleRect = this.el.getBoundingClientRect();

    let top = rect.top - bubbleRect.height - 8;
    let left = rect.left + (rect.width / 2) - (bubbleRect.width / 2);

    if (top < 10) top = rect.bottom + 8;
    if (left < 10) left = 10;
    if (left + bubbleRect.width > window.innerWidth) {
      left = window.innerWidth - bubbleRect.width - 10;
    }

    this.el.style.top = `${top}px`;
    this.el.style.left = `${left}px`;
  }

  show() {
    this.el.classList.remove('dlite-bubble-hidden');
  }

  hide() {
    this.el.classList.add('dlite-bubble-hidden');
  }

  destroy() {
    document.removeEventListener('selectionchange', this._onSelectionChange);
    window.removeEventListener('scroll', this._onScroll);
    if (this.el?.parentNode) {
      this.el.parentNode.removeChild(this.el);
    }
  }
}

// --- Module: src/ui/Toolbar.js ---
/**
 * Toolbar Component for D-Lite Editor
 * Enterprise-grade multi-tier toolbar with Menubar and comprehensive editing controls
 */
class Toolbar {
  constructor(editor) {
    this.editor = editor;
    this.el = null;
    this.activeDropdown = null;
    this.init();
  }

  init() {
    this.el = document.createElement('div');
    this.el.className = 'dlite-toolbar-wrapper';
    this.render();
    this.editor.container.insertBefore(this.el, this.editor.container.firstChild);

    // Crucial: prevent toolbar interactions from stealing focus from canvas!
    this.el.addEventListener('mousedown', (e) => {
      const isInput = e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT';
      if (!isInput) {
        e.preventDefault();
        this.editor.selection.save();
      }
    });

    // Global click to close dropdowns
    this._onDocClick = (e) => {
      if (!this.el.contains(e.target)) {
        this.closeAllDropdowns();
      }
    };
    document.addEventListener('click', this._onDocClick);

    // Update active states on selection changes
    this._onSelectionChange = () => {
      if (document.activeElement === this.editor.canvas) {
        this.updateActiveStates();
      }
    };
    document.addEventListener('selectionchange', this._onSelectionChange);
  }

  render() {
    this.el.innerHTML = `
      <!-- Menubar -->
      <div class="dlite-menubar">
        <div class="dlite-menu-item">
          <button type="button" class="dlite-menu-trigger">Berkas</button>
          <div class="dlite-menu-dropdown">
            <button type="button" class="dlite-menu-action" data-action="clearCanvas">Dokumen Baru / Kosongkan</button>
            <button type="button" class="dlite-menu-action" data-action="preview">Pratinjau Dokumen (Preview)</button>
            <div class="dlite-menu-divider"></div>
            <button type="button" class="dlite-menu-action" data-action="print">Cetak (Ctrl+P)</button>
          </div>
        </div>

        <div class="dlite-menu-item">
          <button type="button" class="dlite-menu-trigger">Edit</button>
          <div class="dlite-menu-dropdown">
            <button type="button" class="dlite-menu-action" data-action="undo">Urungkan (Ctrl+Z)</button>
            <button type="button" class="dlite-menu-action" data-action="redo">Ulangi (Ctrl+Y)</button>
            <div class="dlite-menu-divider"></div>
            <button type="button" class="dlite-menu-action" data-action="selectAll">Pilih Semua (Ctrl+A)</button>
            <button type="button" class="dlite-menu-action" data-action="findReplace">Cari dan Ganti... (Ctrl+F)</button>
          </div>
        </div>

        <div class="dlite-menu-item">
          <button type="button" class="dlite-menu-trigger">Lihat</button>
          <div class="dlite-menu-dropdown">
            <button type="button" class="dlite-menu-action" data-action="preview">Pratinjau Dokumen</button>
            <button type="button" class="dlite-menu-action" data-action="sourceCode">Kode Sumber (HTML)</button>
            <button type="button" class="dlite-menu-action" data-action="fullscreen">Layar Penuh (Zen Mode)</button>
          </div>
        </div>

        <div class="dlite-menu-item">
          <button type="button" class="dlite-menu-trigger">Sisipkan</button>
          <div class="dlite-menu-dropdown">
            <button type="button" class="dlite-menu-action" data-action="image">Gambar (Upload / URL)</button>
            <button type="button" class="dlite-menu-action" data-action="file">Lampiran Berkas (PDF, Dokumen)</button>
            <button type="button" class="dlite-menu-action" data-action="video">Video & Media Embed</button>
            <button type="button" class="dlite-menu-action" data-action="link">Tautan (Link, Ctrl+K)</button>
            <button type="button" class="dlite-menu-action" data-action="unlink">Hapus / Lepas Tautan</button>
            <button type="button" class="dlite-menu-action" data-action="specialChar">Karakter Khusus & Emoji</button>
            <button type="button" class="dlite-menu-action" data-action="dateTime">Tanggal & Waktu Saat Ini</button>
            <div class="dlite-menu-divider"></div>
            <button type="button" class="dlite-menu-action" data-action="blockquote">Kutipan (Blockquote)</button>
            <button type="button" class="dlite-menu-action" data-action="codeBlock">Blok Kode</button>
            <button type="button" class="dlite-menu-action" data-action="hr">Garis Pemisah Horizontal</button>
            <button type="button" class="dlite-menu-action" data-action="pageBreak">Pemisah Halaman (Page Break)</button>
          </div>
        </div>

        <div class="dlite-menu-item">
          <button type="button" class="dlite-menu-trigger">Format</button>
          <div class="dlite-menu-dropdown">
            <button type="button" class="dlite-menu-action" data-action="bold">Tebal (Ctrl+B)</button>
            <button type="button" class="dlite-menu-action" data-action="italic">Miring (Ctrl+I)</button>
            <button type="button" class="dlite-menu-action" data-action="underline">Garis Bawah (Ctrl+U)</button>
            <button type="button" class="dlite-menu-action" data-action="strike">Coret (Strikethrough)</button>
            <button type="button" class="dlite-menu-action" data-action="subscript">Subskrip (X₂)</button>
            <button type="button" class="dlite-menu-action" data-action="superscript">Superskrip (X²)</button>
            <div class="dlite-menu-divider"></div>
            <button type="button" class="dlite-menu-action" data-action="blockquote">Blok Kutipan (Blockquote)</button>
            <button type="button" class="dlite-menu-action" data-action="clearFormat">Hapus Semua Format</button>
          </div>
        </div>

        <div class="dlite-menu-item">
          <button type="button" class="dlite-menu-trigger">Bantuan</button>
          <div class="dlite-menu-dropdown">
            <button type="button" class="dlite-menu-action" data-action="help">Pintasan Keyboard & Panduan (Ctrl+/)</button>
          </div>
        </div>
      </div>

      <!-- Main Toolbar Row 1: Typography & Formatting -->
      <div class="dlite-toolbar-row">
        <!-- History & Utilities -->
        <div class="dlite-toolbar-group">
          <button type="button" class="dlite-tb-btn" data-action="undo" title="Urungkan (Ctrl+Z)">${Icons.undo}</button>
          <button type="button" class="dlite-tb-btn" data-action="redo" title="Ulangi (Ctrl+Y)">${Icons.redo}</button>
          <button type="button" class="dlite-tb-btn" data-action="clearCanvas" title="Dokumen Baru / Kosongkan Kanvas">${Icons.trash}</button>
          <button type="button" class="dlite-tb-btn" data-action="print" title="Cetak Dokumen (Ctrl+P)">${Icons.print}</button>
        </div>
        <div class="dlite-tb-sep"></div>

        <!-- Headings / Blocks -->
        <div class="dlite-toolbar-group">
          <div class="dlite-dropdown" id="dd-block">
            <button type="button" class="dlite-dropdown-btn" data-toggle="dropdown" title="Struktur Paragraf / Heading">
              <span class="dlite-dd-label">Paragraf</span>
              ${Icons.chevronDown}
            </button>
            <div class="dlite-dropdown-menu">
              <button type="button" class="dlite-dd-item" data-block="p">Paragraf Normal</button>
              <button type="button" class="dlite-dd-item dlite-h1-item" data-block="h1">Heading 1</button>
              <button type="button" class="dlite-dd-item dlite-h2-item" data-block="h2">Heading 2</button>
              <button type="button" class="dlite-dd-item dlite-h3-item" data-block="h3">Heading 3</button>
              <button type="button" class="dlite-dd-item dlite-h4-item" data-block="h4">Heading 4</button>
              <button type="button" class="dlite-dd-item" data-block="blockquote">Blok Kutipan</button>
            </div>
          </div>
        </div>

        <!-- Font Family Dropdown -->
        <div class="dlite-toolbar-group">
          <div class="dlite-dropdown" id="dd-fontfamily">
            <button type="button" class="dlite-dropdown-btn" data-toggle="dropdown" title="Jenis Font">
              <span class="dlite-dd-font-label">Inter</span>
              ${Icons.chevronDown}
            </button>
            <div class="dlite-dropdown-menu dlite-font-menu">
              <button type="button" class="dlite-dd-item" data-font="Inter" style="font-family: 'Inter', sans-serif">Inter (Default)</button>
              <button type="button" class="dlite-dd-item" data-font="Arial" style="font-family: Arial, sans-serif">Arial</button>
              <button type="button" class="dlite-dd-item" data-font="Roboto" style="font-family: 'Roboto', sans-serif">Roboto</button>
              <button type="button" class="dlite-dd-item" data-font="Georgia" style="font-family: Georgia, serif">Georgia</button>
              <button type="button" class="dlite-dd-item" data-font="'Times New Roman'" style="font-family: 'Times New Roman', serif">Times New Roman</button>
              <button type="button" class="dlite-dd-item" data-font="'Courier New'" style="font-family: 'Courier New', monospace">Courier New</button>
              <button type="button" class="dlite-dd-item" data-font="Verdana" style="font-family: Verdana, sans-serif">Verdana</button>
              <button type="button" class="dlite-dd-item" data-font="'JetBrains Mono'" style="font-family: 'JetBrains Mono', monospace">JetBrains Mono</button>
            </div>
          </div>
        </div>

        <!-- Font Size Dropdown -->
        <div class="dlite-toolbar-group">
          <div class="dlite-dropdown" id="dd-fontsize">
            <button type="button" class="dlite-dropdown-btn" data-toggle="dropdown" title="Ukuran Font">
              <span class="dlite-dd-size-label">16px</span>
              ${Icons.chevronDown}
            </button>
            <div class="dlite-dropdown-menu dlite-size-menu">
              <button type="button" class="dlite-dd-item" data-size="11px">11px</button>
              <button type="button" class="dlite-dd-item" data-size="12px">12px</button>
              <button type="button" class="dlite-dd-item" data-size="14px">14px</button>
              <button type="button" class="dlite-dd-item" data-size="16px">16px (Normal)</button>
              <button type="button" class="dlite-dd-item" data-size="18px">18px</button>
              <button type="button" class="dlite-dd-item" data-size="20px">20px</button>
              <button type="button" class="dlite-dd-item" data-size="24px">24px</button>
              <button type="button" class="dlite-dd-item" data-size="28px">28px</button>
              <button type="button" class="dlite-dd-item" data-size="32px">32px</button>
              <button type="button" class="dlite-dd-item" data-size="36px">36px</button>
            </div>
          </div>
        </div>

        <!-- Line Height Dropdown -->
        <div class="dlite-toolbar-group">
          <div class="dlite-dropdown" id="dd-lineheight">
            <button type="button" class="dlite-dropdown-btn" data-toggle="dropdown" title="Jarak Spasi Baris (Line Height)">
              ${Icons.lineHeight}
              ${Icons.chevronDown}
            </button>
            <div class="dlite-dropdown-menu dlite-size-menu">
              <button type="button" class="dlite-dd-item" data-lineheight="1.0">1.0 (Rapat)</button>
              <button type="button" class="dlite-dd-item" data-lineheight="1.25">1.25</button>
              <button type="button" class="dlite-dd-item" data-lineheight="1.5">1.5</button>
              <button type="button" class="dlite-dd-item" data-lineheight="1.75">1.75 (Standar)</button>
              <button type="button" class="dlite-dd-item" data-lineheight="2.0">2.0 (Ganda)</button>
              <button type="button" class="dlite-dd-item" data-lineheight="2.5">2.5 (Lebar)</button>
            </div>
          </div>
        </div>
        <div class="dlite-tb-sep"></div>

        <!-- Basic Styling -->
        <div class="dlite-toolbar-group">
          <button type="button" class="dlite-tb-btn" data-action="bold" title="Tebal (Ctrl+B)">${Icons.bold}</button>
          <button type="button" class="dlite-tb-btn" data-action="italic" title="Miring (Ctrl+I)">${Icons.italic}</button>
          <button type="button" class="dlite-tb-btn" data-action="underline" title="Garis Bawah (Ctrl+U)">${Icons.underline}</button>
          <button type="button" class="dlite-tb-btn" data-action="strike" title="Coret (Strikethrough)">${Icons.strikethrough}</button>
          <button type="button" class="dlite-tb-btn" data-action="subscript" title="Subskrip (X₂)">${Icons.subscript}</button>
          <button type="button" class="dlite-tb-btn" data-action="superscript" title="Superskrip (X²)">${Icons.superscript}</button>
          <button type="button" class="dlite-tb-btn" data-action="inlineCode" title="Inline Code">${Icons.code}</button>
          <button type="button" class="dlite-tb-btn" data-action="clearFormat" title="Hapus Format">${Icons.clearFormat}</button>
        </div>
        <div class="dlite-tb-sep"></div>

        <!-- Colors -->
        <div class="dlite-toolbar-group">
          <div class="dlite-dropdown" id="dd-textcolor">
            <button type="button" class="dlite-dropdown-btn" data-toggle="dropdown" title="Warna Teks">
              ${Icons.textColor}
              ${Icons.chevronDown}
            </button>
            <div class="dlite-dropdown-menu dlite-color-palette" data-color-type="text"></div>
          </div>

          <div class="dlite-dropdown" id="dd-bgcolor">
            <button type="button" class="dlite-dropdown-btn" data-toggle="dropdown" title="Warna Sorotan (Highlight)">
              ${Icons.bgColor}
              ${Icons.chevronDown}
            </button>
            <div class="dlite-dropdown-menu dlite-color-palette" data-color-type="bg"></div>
          </div>
        </div>
      </div>

      <!-- Main Toolbar Row 2: Alignment, Lists, Inserts & Tools -->
      <div class="dlite-toolbar-row dlite-toolbar-row-sub">
        <!-- Alignment & Indent -->
        <div class="dlite-toolbar-group">
          <button type="button" class="dlite-tb-btn" data-align="left" title="Rata Kiri">${Icons.alignLeft}</button>
          <button type="button" class="dlite-tb-btn" data-align="center" title="Rata Tengah">${Icons.alignCenter}</button>
          <button type="button" class="dlite-tb-btn" data-align="right" title="Rata Kanan">${Icons.alignRight}</button>
          <button type="button" class="dlite-tb-btn" data-align="justify" title="Rata Kanan Kiri">${Icons.alignJustify}</button>
          <button type="button" class="dlite-tb-btn" data-action="outdent" title="Geser Keluar (Outdent / Shift+Tab)">${Icons.outdent}</button>
          <button type="button" class="dlite-tb-btn" data-action="indent" title="Geser Masuk (Indent / Tab)">${Icons.indent}</button>
        </div>
        <div class="dlite-tb-sep"></div>

        <!-- Lists & Quotes -->
        <div class="dlite-toolbar-group">
          <button type="button" class="dlite-tb-btn" data-action="bulletList" title="Daftar Poin">${Icons.bulletList}</button>
          <button type="button" class="dlite-tb-btn" data-action="numberedList" title="Daftar Nomor">${Icons.numberedList}</button>
          <button type="button" class="dlite-tb-btn" data-action="taskList" title="Daftar Tugas / Checklist">${Icons.taskList}</button>
          <button type="button" class="dlite-tb-btn" data-action="blockquote" title="Kutipan (Blockquote)">${Icons.quote}</button>
        </div>
        <div class="dlite-tb-sep"></div>

        <!-- Media & Elements -->
        <div class="dlite-toolbar-group">
          <button type="button" class="dlite-tb-btn" data-action="link" title="Sisipkan Tautan (Ctrl+K)">${Icons.link}</button>
          <button type="button" class="dlite-tb-btn" data-action="unlink" title="Hapus / Lepas Tautan">${Icons.unlink}</button>
          <button type="button" class="dlite-tb-btn" data-action="image" title="Sisipkan Gambar (Upload / URL)">${Icons.image}</button>
          <button type="button" class="dlite-tb-btn" data-action="file" title="Sisipkan Berkas Dokumen">${Icons.file}</button>
          <button type="button" class="dlite-tb-btn" data-action="video" title="Sisipkan Video (YouTube, Vimeo, Embed)">${Icons.video}</button>
          
          <div class="dlite-dropdown" id="dd-table">
            <button type="button" class="dlite-dropdown-btn" data-toggle="dropdown" title="Sisipkan Tabel">
              ${Icons.table}
              ${Icons.chevronDown}
            </button>
            <div class="dlite-dropdown-menu dlite-table-menu" id="dlite-table-menu-container"></div>
          </div>

          <button type="button" class="dlite-tb-btn" data-action="codeBlock" title="Blok Kode">${Icons.codeBlock}</button>
          <button type="button" class="dlite-tb-btn" data-action="hr" title="Garis Pemisah">${Icons.hr}</button>
          <button type="button" class="dlite-tb-btn" data-action="pageBreak" title="Pemisah Halaman Cetak (Page Break)">${Icons.pageBreak}</button>
          <button type="button" class="dlite-tb-btn" data-action="dateTime" title="Sisipkan Tanggal & Waktu">${Icons.dateTime}</button>
          <button type="button" class="dlite-tb-btn" data-action="specialChar" title="Karakter Khusus & Emoji">${Icons.specialChar}</button>
        </div>
        <div class="dlite-tb-sep"></div>

        <!-- Utilities & View Mode -->
        <div class="dlite-toolbar-group dlite-tb-end">
          <button type="button" class="dlite-tb-btn" data-action="findReplace" title="Cari & Ganti Teks (Ctrl+F)">${Icons.search}</button>
          <button type="button" class="dlite-tb-btn" data-action="selectAll" title="Pilih Semua (Ctrl+A)">${Icons.selectAll}</button>
          <button type="button" class="dlite-tb-btn" data-action="preview" title="Pratinjau Dokumen">${Icons.preview}</button>
          <button type="button" class="dlite-tb-btn" data-action="help" title="Bantuan & Pintasan Keyboard (Ctrl+/)">${Icons.help}</button>
          <button type="button" class="dlite-tb-btn" data-action="sourceCode" title="Kode Sumber HTML">${Icons.sourceCode}</button>
          <button type="button" class="dlite-tb-btn" data-action="fullscreen" title="Layar Penuh (Zen Mode)">${Icons.fullscreen}</button>
        </div>
      </div>
    `;

    this._setupColorPalettes();
    this._setupTablePicker();
    this._bindEvents();
  }

  _setupColorPalettes() {
    const modernColors = [
      '#000000', '#374151', '#6b7280', '#9ca3af', '#ef4444', '#f97316',
      '#f59e0b', '#10b981', '#06b6d4', '#3b82f6', '#6366f1', '#8b5cf6',
      '#ec4899', '#fee2e2', '#fef3c7', '#d1fae5', '#e0f2fe', '#ede9fe'
    ];

    this.el.querySelectorAll('.dlite-color-palette').forEach(palette => {
      const isBg = palette.dataset.colorType === 'bg';
      palette.innerHTML = '';
      
      // Top Clear / Transparent action button
      const clearBtn = document.createElement('button');
      clearBtn.type = 'button';
      clearBtn.className = 'dlite-color-clear-btn';
      clearBtn.innerHTML = isBg ? '🚫 Tanpa Sorotan (Transparan)' : '⚡ Warna Otomatis / Bawaan';
      clearBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (isBg) {
          this.editor.plugins.formatting.removeBgColor();
        } else {
          this.editor.plugins.formatting.textColor('inherit');
        }
        this.closeAllDropdowns();
      });
      palette.appendChild(clearBtn);

      const grid = document.createElement('div');
      grid.className = 'dlite-palette-grid';

      modernColors.forEach(color => {
        const swatch = document.createElement('button');
        swatch.type = 'button';
        swatch.className = 'dlite-color-swatch';
        swatch.style.backgroundColor = color;
        swatch.title = color;
        swatch.addEventListener('click', (e) => {
          e.stopPropagation();
          if (isBg) {
            this.editor.plugins.formatting.bgColor(color);
          } else {
            this.editor.plugins.formatting.textColor(color);
          }
          this.closeAllDropdowns();
        });
        grid.appendChild(swatch);
      });

      palette.appendChild(grid);
    });
  }

  _setupTablePicker() {
    const tableContainer = this.el.querySelector('#dlite-table-menu-container');
    if (tableContainer) {
      const picker = this.editor.plugins.table.createGridPicker((rows, cols) => {
        this.closeAllDropdowns();
        this.editor.plugins.table.insertTable(rows, cols);
      });
      tableContainer.appendChild(picker);
    }
  }

  _bindEvents() {
    // Menubar triggers
    this.el.querySelectorAll('.dlite-menu-trigger').forEach(trigger => {
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        const parent = trigger.closest('.dlite-menu-item');
        const isOpen = parent.classList.contains('dlite-open');
        this.closeAllDropdowns();
        if (!isOpen) {
          parent.classList.add('dlite-open');
        }
      });
    });

    // Menubar action clicks
    this.el.querySelectorAll('.dlite-menu-action').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.closeAllDropdowns();
        const action = btn.dataset.action;
        this._handleAction(action);
      });
    });

    // Dropdown toggles
    this.el.querySelectorAll('[data-toggle="dropdown"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const dd = btn.closest('.dlite-dropdown');
        const isOpen = dd.classList.contains('dlite-open');
        this.closeAllDropdowns();
        if (!isOpen) {
          dd.classList.add('dlite-open');
          this.activeDropdown = dd;
        }
      });
    });

    // Block elements selection
    this.el.querySelectorAll('[data-block]').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const block = item.dataset.block;
        this.editor.plugins.formatting.formatBlock(block);
        const label = this.el.querySelector('#dd-block .dlite-dd-label');
        if (label) label.textContent = item.textContent;
        this.closeAllDropdowns();
      });
    });

    // Font Family selection
    this.el.querySelectorAll('[data-font]').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const font = item.dataset.font;
        this.editor.plugins.formatting.fontFamily(font);
        const label = this.el.querySelector('.dlite-dd-font-label');
        if (label) label.textContent = font.replace(/['"]/g, '');
        this.closeAllDropdowns();
      });
    });

    // Font Size selection
    this.el.querySelectorAll('[data-size]').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const size = item.dataset.size;
        this.editor.plugins.formatting.fontSize(size);
        const label = this.el.querySelector('.dlite-dd-size-label');
        if (label) label.textContent = size;
        this.closeAllDropdowns();
      });
    });

    // Line Height selection
    this.el.querySelectorAll('[data-lineheight]').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const lh = item.dataset.lineheight;
        this.editor.plugins.formatting.lineHeight(lh);
        this.closeAllDropdowns();
      });
    });

    // Alignment buttons
    this.el.querySelectorAll('[data-align]').forEach(btn => {
      btn.addEventListener('click', () => {
        this.editor.plugins.formatting.align(btn.dataset.align);
      });
    });

    // Action buttons
    this.el.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.action;
        this._handleAction(action);
      });
    });
  }

  _handleAction(action) {
    if (this.editor.plugins.code?.isSourceMode && action !== 'sourceCode' && action !== 'fullscreen') {
      toast.warning('Nonaktifkan mode kode sumber (HTML) untuk menggunakan fitur ini.');
      return;
    }

    switch (action) {
      case 'undo': this.editor.history.undo(); break;
      case 'redo': this.editor.history.redo(); break;
      case 'clearCanvas': this.editor.clear(); break;
      case 'print': this.editor.plugins.formatting.print(); break;
      case 'preview': this.editor.preview(); break;
      case 'bold': this.editor.plugins.formatting.bold(); break;
      case 'italic': this.editor.plugins.formatting.italic(); break;
      case 'underline': this.editor.plugins.formatting.underline(); break;
      case 'strike': this.editor.plugins.formatting.strike(); break;
      case 'subscript': this.editor.plugins.formatting.subscript(); break;
      case 'superscript': this.editor.plugins.formatting.superscript(); break;
      case 'inlineCode': this.editor.plugins.formatting.inlineCode(); break;
      case 'clearFormat': this.editor.plugins.formatting.clearFormat(); break;
      case 'outdent': this.editor.plugins.formatting.outdent(); break;
      case 'indent': this.editor.plugins.formatting.indent(); break;
      case 'bulletList': this.editor.plugins.formatting.bulletList(); break;
      case 'numberedList': this.editor.plugins.formatting.numberedList(); break;
      case 'taskList': this.editor.plugins.formatting.taskList(); break;
      case 'blockquote': this.editor.plugins.formatting.blockquote(); break;
      case 'link': this.editor.plugins.link.openModal(); break;
      case 'unlink': this.editor.plugins.link.unlink(); break;
      case 'image': this.editor.plugins.image.openModal(); break;
      case 'file': this.editor.plugins.file.openModal(); break;
      case 'video': this.editor.plugins.mediaEmbed?.openModal(); break;
      case 'codeBlock': this.editor.plugins.code.insertCodeBlock(); break;
      case 'hr': this.editor.plugins.formatting.horizontalRule(); break;
      case 'pageBreak': this.editor.plugins.formatting.pageBreak(); break;
      case 'dateTime': this.editor.plugins.formatting.insertDateTime(); break;
      case 'specialChar': this.editor.plugins.specialChar?.openModal(); break;
      case 'findReplace': this.editor.plugins.findReplace?.openModal(); break;
      case 'selectAll': this.editor.plugins.formatting.selectAll(); break;
      case 'help': this.editor.openHelpModal(); break;
      case 'sourceCode': this.editor.plugins.code.toggleSourceMode(); break;
      case 'fullscreen': this.editor.toggleFullscreen(); break;
    }
  }

  updateActiveStates() {
    if (this._rafPending) return;
    this._rafPending = true;
    requestAnimationFrame(() => {
      this._rafPending = false;
      this._doUpdateActiveStates();
    });
  }

  _doUpdateActiveStates() {
    const checkState = (action, state) => {
      const btn = this.el.querySelector(`[data-action="${action}"]`);
      if (btn) {
        btn.classList.toggle('dlite-active', !!state);
      }
    };

    // Standard inline & list commands
    checkState('bold', this.editor.selection.isFormatActive('bold'));
    checkState('italic', this.editor.selection.isFormatActive('italic'));
    checkState('underline', this.editor.selection.isFormatActive('underline'));
    checkState('strike', this.editor.selection.isFormatActive('strikeThrough'));
    checkState('subscript', document.queryCommandState('subscript'));
    checkState('superscript', document.queryCommandState('superscript'));
    checkState('bulletList', this.editor.selection.isFormatActive('insertUnorderedList'));
    checkState('numberedList', this.editor.selection.isFormatActive('insertOrderedList'));

    // Custom blocks & links
    checkState('blockquote', !!this.editor.selection.getClosest('blockquote'));
    checkState('inlineCode', !!this.editor.selection.getClosest('code.dlite-inline-code'));
    checkState('codeBlock', !!this.editor.selection.getClosest('pre.dlite-code-block'));
    checkState('link', !!this.editor.selection.getClosest('a'));
    checkState('unlink', !!this.editor.selection.getClosest('a'));

    // Alignments
    const alignMap = {
      left: 'justifyLeft',
      center: 'justifyCenter',
      right: 'justifyRight',
      justify: 'justifyFull'
    };
    this.el.querySelectorAll('[data-align]').forEach(btn => {
      const cmd = alignMap[btn.dataset.align];
      if (cmd) {
        btn.classList.toggle('dlite-active', document.queryCommandState(cmd));
      }
    });

    // Paragraph / Heading dropdown label
    const blockLabel = this.el.querySelector('#dd-block .dlite-dd-label');
    if (blockLabel) {
      if (this.editor.selection.getClosest('h1')) blockLabel.textContent = 'Heading 1';
      else if (this.editor.selection.getClosest('h2')) blockLabel.textContent = 'Heading 2';
      else if (this.editor.selection.getClosest('h3')) blockLabel.textContent = 'Heading 3';
      else if (this.editor.selection.getClosest('h4')) blockLabel.textContent = 'Heading 4';
      else if (this.editor.selection.getClosest('blockquote')) blockLabel.textContent = 'Blok Kutipan';
      else blockLabel.textContent = 'Paragraf';
    }
  }

  updateSourceButton(isSource) {
    const btn = this.el.querySelector('[data-action="sourceCode"]');
    if (btn) btn.classList.toggle('dlite-active', isSource);
  }

  closeAllDropdowns() {
    this.el.querySelectorAll('.dlite-dropdown').forEach(dd => dd.classList.remove('dlite-open'));
    this.el.querySelectorAll('.dlite-menu-item').forEach(m => m.classList.remove('dlite-open'));
    this.activeDropdown = null;
  }

  destroy() {
    document.removeEventListener('click', this._onDocClick);
    document.removeEventListener('selectionchange', this._onSelectionChange);
    if (this.el?.parentNode) {
      this.el.parentNode.removeChild(this.el);
    }
  }
}

// --- Module: src/core/Editor.js ---
/**
 * Main DLiteEditor Class
 */
class DLiteEditor {
  constructor(options = {}) {
    this.options = Object.assign({
      selector: null,
      target: null,
      placeholder: 'Tuliskan cerita, laporan, atau artikel Anda di sini...',
      height: '480px',
      theme: 'light', // 'light' | 'dark'
      initialContent: '',
      upload: {},
      onChange: null,
      onInit: null
    }, options);

    this.container = null;
    this.canvas = null;
    this.plugins = {};
    this.events = {};

    this._initDOM();
    this._initCore();
    this._initPlugins();
    this._initUI();
    this._bindEvents();

    if (this.options.initialContent) {
      this.setContent(this.options.initialContent);
    } else {
      // Default initial paragraph
      this.canvas.innerHTML = '<p><br></p>';
    }

    if (typeof this.options.onInit === 'function') {
      this.options.onInit(this);
    }
  }

  _initDOM() {
    let target = this.options.target;
    if (!target && this.options.selector) {
      target = document.querySelector(this.options.selector);
    }

    if (!target) {
      throw new Error(`[D-Lite Editor] Target element tidak ditemukan untuk selector "${this.options.selector}"`);
    }

    this.targetElement = target;

    // Create main container
    this.container = document.createElement('div');
    this.container.className = `dlite-editor-container dlite-theme-${this.options.theme}`;
    if (this.options.height) {
      this.container.style.minHeight = this.options.height;
    }

    // Body wrapper
    const bodyWrapper = document.createElement('div');
    bodyWrapper.className = 'dlite-body-wrapper';

    // Canvas editable
    this.canvas = document.createElement('div');
    this.canvas.className = 'dlite-canvas';
    this.canvas.contentEditable = 'true';
    this.canvas.spellcheck = true;
    this.canvas.setAttribute('data-placeholder', this.options.placeholder);

    bodyWrapper.appendChild(this.canvas);
    this.container.appendChild(bodyWrapper);

    // If target is textarea or input, hide it and place editor after it
    if (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT') {
      target.style.display = 'none';
      if (!this.options.initialContent && target.value) {
        this.options.initialContent = target.value;
      }
      target.parentNode.insertBefore(this.container, target.nextSibling);
    } else {
      if (!this.options.initialContent && target.innerHTML.trim()) {
        this.options.initialContent = target.innerHTML;
      }
      target.innerHTML = '';
      target.appendChild(this.container);
    }
  }

  _initCore() {
    this.selection = new SelectionManager(this);
    this.history = new HistoryManager(this);
  }

  _initPlugins() {
    this.plugins.formatting = new Formatting(this);
    this.plugins.uploader = new Uploader(this, this.options.upload);
    this.plugins.image = new ImagePlugin(this);
    this.plugins.file = new FilePlugin(this);
    this.plugins.link = new LinkPlugin(this);
    this.plugins.table = new TablePlugin(this);
    this.plugins.code = new CodePlugin(this);
    this.plugins.mediaEmbed = new MediaEmbedPlugin(this);
    this.plugins.specialChar = new SpecialCharPlugin(this);
    this.plugins.findReplace = new FindReplacePlugin(this);
  }

  _initUI() {
    this.toolbar = new Toolbar(this);
    this.statusbar = new StatusBar(this);
    this.bubbleMenu = new BubbleMenu(this);
  }

  _bindEvents() {
    // Continuously save selection caret position on canvas interactions
    ['keyup', 'mouseup', 'touchend', 'click'].forEach(evt => {
      this.canvas.addEventListener(evt, () => {
        this.selection.save();
      });
    });

    // Content change observation
    this.canvas.addEventListener('input', () => {
      this._onContentChanged();
      this.history.record();
      this.selection.save();
    });

    // Keyboard shortcuts & Enter key management
    this.canvas.addEventListener('keydown', (e) => {
      // 1. Enter key handling for Tasklist & Highlight cleanup
      if (e.key === 'Enter') {
        const taskItem = this.selection.getClosest('.dlite-task-item');
        if (taskItem) {
          e.preventDefault();
          const textEl = taskItem.querySelector('.dlite-task-text');
          const isBlank = !textEl || !textEl.textContent.trim();
          if (isBlank) {
            const p = document.createElement('p');
            p.innerHTML = '<br>';
            taskItem.replaceWith(p);
            const range = document.createRange();
            range.setStart(p, 0);
            range.collapse(true);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
          } else {
            const newItem = document.createElement('div');
            newItem.className = 'dlite-task-item';
            newItem.innerHTML = `
              <input type="checkbox" class="dlite-task-checkbox" contenteditable="false" />
              <span class="dlite-task-text" contenteditable="true"><br></span>
            `;
            taskItem.after(newItem);
            const newText = newItem.querySelector('.dlite-task-text');
            const range = document.createRange();
            range.setStart(newText, 0);
            range.collapse(true);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
          }
          this.selection.save();
          this._onContentChanged();
          this.history.record(true);
          return;
        }

        // Prevent background-color highlight bleeding into new lines
        setTimeout(() => {
          const sel = window.getSelection();
          if (sel && sel.rangeCount > 0) {
            const range = sel.getRangeAt(0);
            let node = range.startContainer;
            if (node.nodeType === Node.TEXT_NODE) node = node.parentNode;
            const span = node.closest ? node.closest('span[style*="background"]') : null;
            if (span && (!span.textContent.trim() || span.innerHTML === '<br>')) {
              span.style.backgroundColor = '';
              if (!span.getAttribute('style')) {
                while (span.firstChild) span.parentNode.insertBefore(span.firstChild, span);
                span.remove();
              }
            }
          }
          this.selection.save();
        }, 10);
      }

      // 2. Tab key handling for Indent / Outdent
      if (e.key === 'Tab') {
        e.preventDefault();
        if (e.shiftKey) {
          this.plugins.formatting.outdent();
        } else {
          this.plugins.formatting.indent();
        }
      }

      // 3. Standard Command/Ctrl Shortcuts
      if (e.ctrlKey || e.metaKey) {
        switch (e.key.toLowerCase()) {
          case 'b':
            e.preventDefault();
            this.plugins.formatting.bold();
            break;
          case 'i':
            e.preventDefault();
            this.plugins.formatting.italic();
            break;
          case 'u':
            e.preventDefault();
            this.plugins.formatting.underline();
            break;
          case 'z':
            e.preventDefault();
            if (e.shiftKey) {
              this.history.redo();
            } else {
              this.history.undo();
            }
            break;
          case 'y':
            e.preventDefault();
            this.history.redo();
            break;
          case 'k':
            e.preventDefault();
            this.plugins.link.openModal();
            break;
          case 'f':
            e.preventDefault();
            this.plugins.findReplace?.openModal();
            break;
          case 'p':
            e.preventDefault();
            this.plugins.formatting?.print();
            break;
          case '/':
          case '?':
            e.preventDefault();
            this.openHelpModal();
            break;
        }
      }
    });

    // Checkbox state synchronization for tasklist
    this.canvas.addEventListener('change', (e) => {
      if (e.target.classList.contains('dlite-task-checkbox')) {
        if (e.target.checked) {
          e.target.setAttribute('checked', '');
        } else {
          e.target.removeAttribute('checked');
        }
        this._onContentChanged();
        this.history.record(true);
      }
    });

    this._initFormSync();
  }

  _initFormSync() {
    if (this.targetElement && this.targetElement.form) {
      this._formSubmitHandler = () => {
        this.targetElement.value = this.getContent();
      };
      this.targetElement.form.addEventListener('submit', this._formSubmitHandler);
    }
  }

  _onContentChanged(immediate = false) {
    // 1. Immediately update status bar (word count, reading time) - ultra-fast textContent
    if (this.statusbar) {
      this.statusbar.update(immediate);
    }

    // 2. Fast raw HTML sync with target textarea so form data is always populated without DOMParser lag
    if (this.targetElement && (this.targetElement.tagName === 'TEXTAREA' || this.targetElement.tagName === 'INPUT')) {
      this.targetElement.value = this.getRawHTML();
    }

    // 3. Debounce expensive Sanitizer.clean() and change callbacks during rapid typing to eliminate input lag
    if (immediate) {
      clearTimeout(this._changeDebounceTimer);
      this._emitSanitizedChange();
    } else {
      clearTimeout(this._changeDebounceTimer);
      this._changeDebounceTimer = setTimeout(() => {
        this._emitSanitizedChange();
      }, 250);
    }
  }

  _emitSanitizedChange() {
    const html = this.getContent();
    if (this.targetElement && (this.targetElement.tagName === 'TEXTAREA' || this.targetElement.tagName === 'INPUT')) {
      this.targetElement.value = html;
    }
    if (typeof this.options.onChange === 'function') {
      this.options.onChange(html);
    }
    this.emit('change', html);
  }

  /**
   * Fast raw HTML retrieval without parsing overhead
   * @returns {string}
   */
  getRawHTML() {
    if (this.plugins.code && this.plugins.code.isSourceMode) {
      return this.plugins.code.sourceTextarea.value;
    }
    return this.canvas.innerHTML;
  }

  /**
   * Returns clean sanitized HTML content
   * @returns {string}
   */
  getContent() {
    if (this.plugins.code && this.plugins.code.isSourceMode) {
      return Sanitizer.clean(this.plugins.code.sourceTextarea.value);
    }
    return Sanitizer.clean(this.canvas.innerHTML);
  }

  /**
   * Sets editor HTML content
   * @param {string} html 
   */
  setContent(html) {
    const clean = Sanitizer.clean(html);
    this.canvas.innerHTML = clean || '<p><br></p>';
    this.history.clear();
    this.history.record(true);
    this._onContentChanged(true);
  }

  getHTML() {
    return this.canvas.innerHTML;
  }

  getText() {
    return this.canvas.innerText || '';
  }

  /**
   * Clear content with custom confirmation modal (NO window.confirm!)
   */
  async clear() {
    const confirmed = await modal.confirm({
      title: 'Kosongkan Kanvas',
      message: 'Apakah Anda yakin ingin menghapus semua isi tulisan di editor?',
      confirmText: 'Kosongkan',
      isDestructive: true
    });

    if (confirmed) {
      this.setContent('<p><br></p>');
      toast.info('Kanvas telah dikosongkan.');
    }
  }

  /**
   * Toggle between Dark Mode and Light Mode
   */
  toggleTheme() {
    const isDark = this.container.classList.contains('dlite-theme-dark');
    this.container.classList.toggle('dlite-theme-dark', !isDark);
    this.container.classList.toggle('dlite-theme-light', isDark);
    toast.info(`Tema diubah ke ${!isDark ? 'Mode Gelap' : 'Mode Terang'}`);
  }

  /**
   * Zen / Fullscreen Toggle
   */
  toggleFullscreen() {
    const isFull = this.container.classList.toggle('dlite-fullscreen');
    if (isFull) {
      document.body.style.overflow = 'hidden';
      toast.info('Mode Layar Penuh aktif. Tekan kembali untuk keluar.');
    } else {
      document.body.style.overflow = '';
    }
  }

  /**
   * Preview document modal
   */
  preview() {
    const rawHtml = this.getHTML();
    const cleanHtml = Sanitizer.clean(rawHtml);

    const content = document.createElement('div');
    content.className = 'dlite-preview-modal-body';
    content.innerHTML = `
      <div class="dlite-preview-toolbar">
        <div class="dlite-preview-devices">
          <button type="button" class="dlite-preview-btn active" data-device="desktop">Desktop (100%)</button>
          <button type="button" class="dlite-preview-btn" data-device="tablet">Tablet (768px)</button>
          <button type="button" class="dlite-preview-btn" data-device="mobile">Ponsel (375px)</button>
        </div>
        <button type="button" class="dlite-preview-print-btn">${Icons.print} Cetak Dokumen</button>
      </div>
      <div class="dlite-preview-viewport-wrapper">
        <div class="dlite-preview-viewport" data-device="desktop">
          <div class="dlite-preview-rendered-content dlite-canvas">
            ${cleanHtml || '<p style="color:#94a3b8;font-style:italic">Dokumen masih kosong...</p>'}
          </div>
        </div>
      </div>
    `;

    // Device switcher
    const buttons = content.querySelectorAll('.dlite-preview-btn');
    const viewport = content.querySelector('.dlite-preview-viewport');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        viewport.setAttribute('data-device', btn.dataset.device);
      });
    });

    content.querySelector('.dlite-preview-print-btn').addEventListener('click', () => {
      this.plugins.formatting.print();
    });

    modal.open({
      title: 'Pratinjau Dokumen (Preview)',
      content,
      width: '880px',
      buttons: [
        { text: 'Tutup Pratinjau', type: 'primary' }
      ]
    });
  }

  /**
   * Help & Keyboard Shortcuts Modal
   */
  openHelpModal() {
    const content = document.createElement('div');
    content.className = 'dlite-help-modal-body';
    content.innerHTML = `
      <div class="dlite-help-section">
        <h4>Pintasan Keyboard (Shortcuts)</h4>
        <div class="dlite-shortcuts-grid">
          <div class="dlite-sc-row"><kbd>Ctrl + B</kbd><span>Teks Tebal (Bold)</span></div>
          <div class="dlite-sc-row"><kbd>Ctrl + I</kbd><span>Teks Miring (Italic)</span></div>
          <div class="dlite-sc-row"><kbd>Ctrl + U</kbd><span>Garis Bawah (Underline)</span></div>
          <div class="dlite-sc-row"><kbd>Ctrl + Z</kbd><span>Urungkan (Undo)</span></div>
          <div class="dlite-sc-row"><kbd>Ctrl + Y</kbd><span>Ulangi (Redo)</span></div>
          <div class="dlite-sc-row"><kbd>Ctrl + A</kbd><span>Pilih Semua Teks</span></div>
          <div class="dlite-sc-row"><kbd>Ctrl + F</kbd><span>Cari & Ganti Teks</span></div>
          <div class="dlite-sc-row"><kbd>Ctrl + K</kbd><span>Sisipkan Tautan</span></div>
          <div class="dlite-sc-row"><kbd>Ctrl + P</kbd><span>Cetak Dokumen</span></div>
          <div class="dlite-sc-row"><kbd>Ctrl + /</kbd><span>Buka Panduan Bantuan</span></div>
          <div class="dlite-sc-row"><kbd>Tab</kbd><span>Geser Masuk (Indent)</span></div>
          <div class="dlite-sc-row"><kbd>Shift + Tab</kbd><span>Geser Keluar (Outdent)</span></div>
          <div class="dlite-sc-row"><kbd>Shift + Enter</kbd><span>Baris Baru Tanpa Paragraf</span></div>
        </div>
      </div>
      <div class="dlite-help-section" style="margin-top: 16px;">
        <h4>Fitur Unggulan D-Lite Editor</h4>
        <ul class="dlite-help-features">
          <li><strong>Upload Langsung:</strong> Seret (drag & drop) gambar atau file dokumen langsung ke editor untuk upload instan dengan progress bar.</li>
          <li><strong>Checklist Interaktif:</strong> Tekan Enter untuk menambah tugas baru secara otomatis di posisi kursor.</li>
          <li><strong>Perataan Media:</strong> Gambar dan berkas lampiran mendukung perataan kiri, tengah, dan kanan.</li>
          <li><strong>Pembersih Format:</strong> Tombol Hapus Format membersihkan inline styles dan highlight background tanpa merusak struktur dokumen.</li>
        </ul>
      </div>
    `;

    modal.open({
      title: 'Bantuan & Pintasan Keyboard',
      content,
      width: '580px',
      buttons: [
        { text: 'Mengerti', type: 'primary' }
      ]
    });
  }

  /**
   * Event listener subscription
   */
  on(event, handler) {
    if (!this.events[event]) this.events[event] = [];
    this.events[event].push(handler);
  }

  emit(event, data) {
    if (this.events[event]) {
      this.events[event].forEach(fn => fn(data));
    }
  }

  destroy() {
    clearTimeout(this._changeDebounceTimer);

    if (this.targetElement?.form && this._formSubmitHandler) {
      this.targetElement.form.removeEventListener('submit', this._formSubmitHandler);
    }

    // 1. Clean up UI components and global document listeners
    if (this.toolbar) {
      this.toolbar.destroy();
    }
    if (this.statusbar) {
      this.statusbar.destroy();
    }
    if (this.bubbleMenu) {
      this.bubbleMenu.destroy();
    }

    // 2. Clean up plugins and unbind window/document listeners
    if (this.plugins?.image?.destroy) {
      this.plugins.image.destroy();
    }
    if (this.plugins?.link?.destroy) {
      this.plugins.link.destroy();
    }
    if (this.plugins?.table?.destroy) {
      this.plugins.table.destroy();
    }

    // 3. Remove main container and restore target element
    if (this.container && this.container.parentNode) {
      if (this.targetElement) {
        this.targetElement.style.display = '';
      }
      this.container.parentNode.removeChild(this.container);
    }

    // 4. Reset document overflow in case fullscreen was active
    document.body.style.overflow = '';
  }
}

  return {
    DLiteEditor: DLiteEditor,
    DLiteToast: DLiteToast,
    DLiteModal: DLiteModal,
    toast: toast,
    modal: modal,
    Sanitizer: Sanitizer,
    Icons: Icons,
    default: DLiteEditor
  };
});
